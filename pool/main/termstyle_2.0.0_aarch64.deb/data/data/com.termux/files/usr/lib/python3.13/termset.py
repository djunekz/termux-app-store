#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════╗
║         T E R M S T Y L E  v2.0.0           ║
║   Termux Terminal Customization Tool         ║
║   Pembuat : Djunekz/Hmei7/RedHh/MrxXx       ║
║   Email   : gab288.gab288@passinbox.com      ║
║   Repo    : github.com/djunekz/termstyle     ║
║   Lisensi : GNU General Public License v3    ║
╚══════════════════════════════════════════════╝
"""

# ─── ANSI COLOR CODES ───────────────────────────────────────────
RESET  = '\033[0m'
BOLD   = '\033[1m'
DIM    = '\033[2m'

# Regular colors
BLACK   = '\033[30m'
RED     = '\033[31m'
GREEN   = '\033[32m'
YELLOW  = '\033[33m'
BLUE    = '\033[34m'
MAGENTA = '\033[35m'
CYAN    = '\033[36m'
WHITE   = '\033[37m'

# Bright colors
DG = '\033[90m'   # Dark Gray
LR = '\033[91m'   # Light Red
LG = '\033[92m'   # Light Green
LY = '\033[93m'   # Light Yellow
LB = '\033[94m'   # Light Blue
LM = '\033[95m'   # Light Magenta
LC = '\033[96m'   # Light Cyan
LW = '\033[97m'   # Light White

CL = RESET

# ─── STATUS SYMBOLS ─────────────────────────────────────────────
error  = LY + '[' + LR + '!' + LY + '] ' + LR
sukses = LY + '[' + LG + '✓' + LY + '] ' + LG
info   = LY + '[' + LC + '*' + LY + '] ' + LC
up     = LY + '[' + LM + '+' + LY + '] ' + LG
dwn    = LY + '[' + LC + '-' + LY + '] ' + LG
ask    = LY + '[' + LW + '?' + LY + '] ' + LG
warn   = LY + '[' + YELLOW + '⚠' + LY + '] ' + YELLOW

# ─── VERSION ────────────────────────────────────────────────────
VERSION = '{}2.0.0{}'.format(LG, CL)

# ─── ASCII LOGO ─────────────────────────────────────────────────
LOGO = """{}
 _____               _____ _       _      
|_   _|___ ___ _____|   __| |_ _ _| |___  
  | | | -_|  _|     |__   |  _| | | | -_| 
  |_| |___|_| |_|_|_|_____|_| |_  |_|___| 
   {} T E R M U X   S T Y L E{}   |___| {}    
{}""".format(LY, LM, LY, VERSION, LY, CL)

# ─── COLOR THEMES ───────────────────────────────────────────────
# Format: (name, description, background, foreground, cursor_color, color_accent)
COLOR_THEMES = {
    '1': ('Cyberpunk',    'Dark neon vibe',
          '#0a0a0f', '#00ffcc', '#ff3cac', '#ffe94d'),
    '2': ('Matrix',       'Classic green on black',
          '#000000', '#00ff41', '#39ff82', '#003b00'),
    '3': ('Dracula',      'Purple gothic dark',
          '#282a36', '#f8f8f2', '#ff79c6', '#bd93f9'),
    '4': ('Nord',         'Arctic cool blue',
          '#2e3440', '#d8dee9', '#88c0d0', '#81a1c1'),
    '5': ('Tokyo Night',  'Urban midnight neon',
          '#1a1b26', '#c0caf5', '#7aa2f7', '#bb9af7'),
    '6': ('Gruvbox',      'Warm retro earth tones',
          '#282828', '#ebdbb2', '#d79921', '#689d6a'),
    '7': ('Catppuccin',   'Pastel mocha smooth',
          '#1e1e2e', '#cdd6f4', '#cba6f7', '#89b4fa'),
    '8': ('One Dark',     'Atom editor classic',
          '#282c34', '#abb2bf', '#61afef', '#98c379'),
    '9': ('Solarized',    'Eye-friendly dark',
          '#002b36', '#839496', '#268bd2', '#2aa198'),
    '0': ('Custom',       'Set your own colors', None, None, None, None),
}

# ─── PROMPT STYLES (PS1) ────────────────────────────────────────
# preview : string ANSI murni untuk print() di Python
# ps1     : string PS1 bash (pakai \[..\] untuk non-printing chars)
PROMPT_STYLES = {
    '1': {
        'name': 'Kali Style',
        'desc': 'Dua baris, ala Kali Linux — pro dan clean',
        'preview': (
            "\033[1;33m┌──[\033[1;92mtermux\033[1;38m@\033[1;92mlocalhost"
            "\033[1;33m]─[\033[0m~/projects\033[1;33m]\033[0m\n"
            "\033[1;33m└─\033[1;92m$ \033[0m"
        ),
        'ps1': (
            "PS1='\\[\\e[1;33m\\]┌──[\\[\\e[1;92m\\]\\u"
            "\\[\\e[1;38m\\]@\\[\\e[1;92m\\]\\h"
            "\\[\\e[1;33m\\]]─[\\[\\e[0m\\]\\w"
            "\\[\\e[1;33m\\]]\\n\\[\\e[1;33m\\]└─"
            "\\[\\e[1;92m\\]\\$\\[\\e[0m\\] '"
        ),
    },
    '2': {
        'name': 'Classic Inline',
        'desc': 'Satu baris, ringkas dan cepat',
        'preview': (
            "\033[1;36m[\033[1;92muser\033[0m@\033[1;92mtermux"
            "\033[1;36m] \033[1;33m~/projects \033[0m$ \033[0m"
        ),
        'ps1': (
            "PS1='\\[\\e[1;36m\\][\\[\\e[1;92m\\]\\u"
            "\\[\\e[0m\\]@\\[\\e[1;92m\\]\\h\\[\\e[1;36m\\]]"
            "\\[\\e[1;33m\\] \\w \\[\\e[0m\\]\\$ '"
        ),
    },
    '3': {
        'name': 'Powerline',
        'desc': 'Modern, ada git branch info (butuh git)',
        'preview': (
            "\033[1;35m❯\033[0m \033[1;97mtermux "
            "\033[1;33m~/projects "
            "\033[1;36mgit:(main)\033[0m "
        ),
        'ps1': (
            "PS1='\\[\\e[1;35m\\]❯\\[\\e[0m\\] \\[\\e[1;97m\\]\\h "
            "\\[\\e[1;33m\\]\\w \\[\\e[1;36m\\]$(git branch "
            "--show-current 2>/dev/null | sed \"s/.*/(&)/\")"
            "\\[\\e[0m\\] '"
        ),
    },
    '4': {
        'name': 'Box Style',
        'desc': 'Double-line box, cocok untuk root',
        'preview': (
            "\033[1;33m╔═[\033[1;96mtermux\033[1;33m]═["
            "\033[0m~/projects\033[1;33m]\033[0m\n"
            "\033[1;33m╚══\033[1;92m# \033[0m"
        ),
        'ps1': (
            "PS1='\\[\\e[1;33m\\]╔═[\\[\\e[1;96m\\]\\h"
            "\\[\\e[1;33m\\]]═[\\[\\e[0m\\]\\w\\[\\e[1;33m\\]]\\n"
            "\\[\\e[1;33m\\]╚══\\[\\e[1;92m\\]#\\[\\e[0m\\] '"
        ),
    },
    '5': {
        'name': 'Lambda',
        'desc': 'Minimal elegan, simbol λ sebagai prompt',
        'preview': (
            "\033[1;32m▶\033[0m ~/home "
            "\033[1;36mon\033[0m main "
            "\033[1;33mλ\033[0m "
        ),
        'ps1': (
            "PS1='\\[\\e[1;32m\\]▶\\[\\e[0m\\] \\w "
            "\\[\\e[1;36m\\]on\\[\\e[0m\\] "
            "$(git branch --show-current 2>/dev/null || echo -) "
            "\\[\\e[1;33m\\]λ\\[\\e[0m\\] '"
        ),
    },
    '6': {
        'name': 'HTB Style',
        'desc': 'HackTheBox/root vibes, cocok buat pentesting',
        'preview': (
            "\033[1;31m╭─(\033[1;35mroot\033[0m㉿"
            "\033[1;36mtermux\033[1;31m)─[\033[0m~"
            "\033[1;31m]\033[0m\n"
            "\033[1;31m╰─\033[0m# "
        ),
        'ps1': (
            "PS1='\\[\\e[1;31m\\]╭─(\\[\\e[1;35m\\]\\u"
            "\\[\\e[0m\\]㉿\\[\\e[1;36m\\]\\h"
            "\\[\\e[1;31m\\])─[\\[\\e[0m\\]\\w"
            "\\[\\e[1;31m\\]]\\n\\[\\e[1;31m\\]╰─"
            "\\[\\e[0m\\]# '"
        ),
    },
}

# ─── CURSOR STYLES ──────────────────────────────────────────────
CURSOR_STYLES = {
    '1': ('underline', 'Underline  ▁', 'Garis bawah, halus dan subtle'),
    '2': ('bar',       'Bar        |', 'Cursor vertikal, modern'),
    '3': ('block',     'Block      █', 'Kotak penuh, klasik dan bold'),
}

# ─── FONT OPTIONS ───────────────────────────────────────────────
FONTS = {
    '1': ('Hack Nerd Font',       'Hack NF — Clean dan mudah dibaca'),
    '2': ('FiraCode Nerd Font',   'FiraCode NF — Ada ligatures keren'),
    '3': ('JetBrainsMono NF',     'JetBrains — Font IDE populer'),
    '4': ('Cascadia Code NF',     'Cascadia — Font VS Code default'),
    '5': ('MesloLGS NF',          'MesloLGS — Recommended Oh-My-Zsh'),
    '6': ('SourceCodePro NF',     'SourceCode Pro — Adobe, clean'),
}

# ─── FONT INSTALL COMMANDS ──────────────────────────────────────
FONT_INSTALL = {
    'Hack Nerd Font':     'pkg install -y font-hack-nerd',
    'FiraCode Nerd Font': 'pkg install -y font-fira-code-nerd',
    'JetBrainsMono NF':   'pkg install -y font-jetbrains-mono-nerd',
    'Cascadia Code NF':   'pkg install -y font-cascadia-code-nerd',
    'MesloLGS NF':        'pkg install -y font-meslo-nerd',
    'SourceCodePro NF':   'pkg install -y font-source-code-pro-nerd',
}

# ─── MAIN MENUS ─────────────────────────────────────────────────
MENU_MAIN = """
{}[{}1{}]{}  🎨  Color Theme       {}─{}  10 preset + custom
{}[{}2{}]{}  $   Command Prompt    {}─{}  6 gaya PS1
{}[{}3{}]{}  |   Cursor Style      {}─{}  3 bentuk + blink
{}[{}4{}]{}  A   Font Style        {}─{}  6 Nerd Font
{}[{}5{}]{}  👁   Live Preview      {}─{}  lihat hasilnya
{}[{}i{}]{}  ?   Info & About      {}─{}  info tool
{}[{}x{}]{}  ✕   Exit              {}─{}  keluar
""".format(
    LG, LW, LG, LY, DG, LY,
    LG, LW, LG, LY, DG, LY,
    LG, LW, LG, LY, DG, LY,
    LG, LW, LG, LY, DG, LY,
    LG, LW, LG, LY, DG, LY,
    LG, LW, LG, LY, DG, LY,
    LG, LR, LG, LR, DG, LR,
)
