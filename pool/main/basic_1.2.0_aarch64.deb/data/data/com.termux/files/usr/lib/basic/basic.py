import os
import time
import random
import textwrap
import hashlib
from datetime import datetime

# Tools ini dibuat dengan tujuan pembelajaran para pemula yang ingin belajar dasar linux
# Script ini sudah di sediakan Symbol '#'
# untuk informasi bagi pemula yang ingin baca script
# Tool ini gratis tidak diperjual belikan!
# Script ini saya buat Open-Source (Terbuka)
# Supaya semua orang yang membuka script ini bisa belajar coding
#
# Tools ini ditulis manual menggunakan Kali Linux, Termux
# Proses pengerjaan dari basic versi 1.0.0 ke versi 1.2.0 membutuhkan ± 8 bulan
# Tool ini murni tanpa AI
#
# Developer: Djunekz
# Tiktok: anonymous_id_
# Github: https://github.com/djunekz
# Github repository: https://github.com/djunekz/basic
# Github installer tool: https://github.com/djunekz/termux-app-store
#
# Source link code ASCII BASIC: https://patorjk.com/software/taag
# Source link symbol line: https://id.piliapp.com/symbol/line/
#
# DARI BELAJAR KAMU AKAN BISA
# YANG AHLI BERAWAL DARI TIDAK TAU APA-APA
#

# ─── WARNA ANSI ────────────────────────────────────────────────────────────────
R  = '\033[91m'   # Merah
G  = '\033[92m'   # Hijau
Y  = '\033[93m'   # Kuning
B  = '\033[94m'   # Biru
M  = '\033[95m'   # Magenta
C  = '\033[96m'   # Cyan
W  = '\033[97m'   # Putih terang
DG = '\033[90m'   # Abu-abu gelap
N  = '\033[0m'    # Reset
BOLD = '\033[1m'
UL   = '\033[4m'
# Untuk belajar / mengetahui code-code warna, bentuk tulisan, dll. bisa gunakan tool 'bashxt'

# ─── BANNER ────────────────────────────────────────────────────────────────────
BANNER = f"""
{R}╔═════════════════════════════════════════════════════════════════╗
{R}║{Y}              ██████╗  █████╗ ███████╗██╗ ██████╗                {R}║
{R}║{Y}              ██╔══██╗██╔══██╗██╔════╝██║██╔════╝                {R}║
{R}║{Y}              ██████╔╝███████║███████╗██║██║                     {R}║
{R}║{Y}              ██╔══██╗██╔══██║╚════██║██║██║                     {R}║
{R}║{Y}              ██████╔╝██║  ██║███████║██║╚██████╗                {R}║
{R}║{Y}              ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝ ╚═════╝                {R}║
{R}╠═════════════════════════════════════════════════════════════════╣
{R}║{C}     Simulator Untuk belajar Perintah Dasar Linux / Termux       {R}║
{R}║{W}       Belajar Linux dari NOL sampai MAHIR dengan mudah!         {R}║
{R}╚═════════════════════════════════════════════════════════════════╝{N}
"""

# ─── SISTEM FILE SIMULASI ───────────────────────────────────────────────────────
simulated_filesystem = {
    'home': {
        'user': {
            'documents': {
                'laporan.txt': "Ini adalah laporan penting perusahaan.\nDibuat pada tahun 2024.\nHarap dijaga kerahasiaannya.",
                'catatan.md': "# Catatan Belajar Linux\n\n## Dasar\n- ls, cd, pwd\n- mkdir, touch, rm\n\n## Menengah\n- grep, find, chmod\n- pipe, redirect\n\n## Lanjutan\n- awk, sed, tar\n- cron, systemctl",
                'todo.txt': "[ ] Belajar perintah dasar Linux\n[ ] Pahami permission file\n[ ] Pelajari shell scripting\n[x] Install Termux\n[x] Update packages",
                'readme.txt': "Selamat datang di folder documents!\nFolder ini berisi file-file penting.\nJangan hapus sembarangan ya!",
            },
            'downloads': {
                'foto.jpg': '[binary: file gambar JPEG, 2.4MB]',
                'musik.mp3': '[binary: file audio MP3, 5.1MB]',
                'arsip.zip': '[binary: file ZIP berisi 12 file, 15.3MB]',
                'installer.sh': "#!/bin/bash\necho 'Memulai instalasi...'\napt update && apt upgrade -y\necho 'Instalasi selesai!'",
            },
            'pictures': {
                'liburan': {
                    'pantai.jpg': '[binary: file gambar JPEG, 3.2MB]',
                    'gunung.jpg': '[binary: file gambar JPEG, 2.8MB]',
                },
                'kerja': {},
            },
            'videos': {
                'tutorial_linux.mp4': '[binary: file video MP4, 120MB]',
            },
            'projects': {
                'web': {
                    'index.html': '<!DOCTYPE html>\n<html>\n<head><title>My Web</title></head>\n<body>\n  <h1>Hello World!</h1>\n  <p>Website pertamaku.</p>\n</body>\n</html>',
                    'style.css': 'body {\n  font-family: Arial, sans-serif;\n  background: #f0f0f0;\n}\nh1 {\n  color: #333;\n}',
                    'script.js': 'console.log("Hello from JavaScript!");\ndocument.addEventListener("DOMContentLoaded", () => {\n  console.log("Page loaded!");\n});',
                },
                'python': {
                    'hello.py': 'print("Hello, World!")\nname = input("Siapa namamu? ")\nprint(f"Halo, {name}!")',
                    'kalkulator.py': 'def tambah(a, b): return a + b\ndef kurang(a, b): return a - b\nprint(tambah(10, 5))\nprint(kurang(10, 5))',
                },
            },
            '.bashrc': 'export PATH=$PATH:/usr/local/bin\nalias ll="ls -la"\nalias cls="clear"\nPS1="\\u@\\h:\\w$ "',
            '.profile': '# ~/.profile - dibaca saat login\nexport EDITOR=nano\nexport LANG=id_ID.UTF-8',
            'hello.py': 'print("Halo dunia!")\nprint("Selamat belajar Python & Linux!")',
            'notes.txt': 'Ini catatan harianku.\nBelajar itu menyenangkan!\nJangan menyerah!',
        }
    },
    'etc': {
        'hosts': '127.0.0.1   localhost\n127.0.1.1   mycomputer\n::1         localhost ip6-localhost',
        'passwd': 'root:x:0:0:root:/root:/bin/bash\nuser:x:1000:1000:User:/home/user:/bin/bash',
        'os-release': 'NAME="Ubuntu"\nVERSION="22.04 LTS"\nID=ubuntu\nPRETTY_NAME="Ubuntu 22.04 LTS"',
    },
    'tmp': {
        'temp_file.txt': 'File sementara ini akan dihapus saat reboot.',
    },
    'var': {
        'log': {
            'syslog': '[2024-01-15 08:00:01] System started\n[2024-01-15 08:00:05] Network connected\n[2024-01-15 08:01:22] User login: user',
        }
    }
}

current_path_list = ['home', 'user']
command_history   = []
alias_dict        = {'ll': 'ls -la', 'cls': 'clear', 'c': 'clear'}
env_vars          = {
    'HOME': '/home/user',
    'USER': 'user',
    'PATH': '/usr/local/bin:/usr/bin:/bin',
    'SHELL': '/bin/bash',
    'TERM': 'xterm-256color',
    'LANG': 'id_ID.UTF-8',
    'PWD':  '/home/user',
}
file_permissions  = {}   # path_str -> 'rwxr-xr-x'
command_count     = {'total': 0, 'correct': 0}

# ─── UTILITAS ──────────────────────────────────────────────────────────────────
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def wrap(text, width=72, indent='  '):
    return '\n'.join(textwrap.wrap(text, width=width, initial_indent=indent, subsequent_indent=indent))

def path_str(path_list):
    return '/' + '/'.join(path_list) if path_list else '/'

def get_dir(path_list):
    node = simulated_filesystem
    for p in path_list:
        if isinstance(node, dict) and p in node:
            node = node[p]
        else:
            return None
    return node if isinstance(node, dict) else None

def get_node(path_list):
    """Return raw node (dict or string)."""
    node = simulated_filesystem
    for p in path_list:
        if isinstance(node, dict) and p in node:
            node = node[p]
        else:
            return None
    return node

def resolve_path(base, target):
    if target.startswith('/'):
        parts = [p for p in target.strip('/').split('/') if p]
    else:
        parts = list(base)
        for p in target.split('/'):
            if p == '..':
                if parts:
                    parts.pop()
            elif p and p != '.':
                parts.append(p)
    return parts

def file_size(content):
    if isinstance(content, str):
        return len(content.encode())
    return 0

def format_size(n):
    if n < 1024:      return f"{n}B"
    if n < 1048576:   return f"{n//1024}K"
    return f"{n//1048576}M"

def get_perm(path_key, is_dir):
    return file_permissions.get(path_key, 'drwxr-xr-x' if is_dir else '-rw-r--r--')

def set_perm(path_key, perm_str):
    file_permissions[path_key] = perm_str

def fake_date():
    return datetime.now().strftime('%b %d %H:%M')

def print_tip(msg):
    print(f"\n{DG}  TIP: {msg}{N}")

def print_error(msg):
    print(f"{R}  ✗ {msg}{N}")

def print_ok(msg):
    print(f"{G}  ✓ {msg}{N}")

def print_info(msg):
    print(f"{C}  ℹ {msg}{N}")

# ─── HELP LENGKAP ──────────────────────────────────────────────────────────────
HELP_CATEGORIES = {
    'navigasi':     ['ls', 'pwd', 'cd', 'tree'],
    'file':         ['touch', 'mkdir', 'cp', 'mv', 'rm', 'rename'],
    'isi_file':     ['cat', 'head', 'tail', 'more', 'wc', 'echo', 'tee'],
    'cari':         ['find', 'grep', 'locate', 'which'],
    'permission':   ['chmod', 'chown', 'stat', 'umask'],
    'proses':       ['ps', 'top', 'kill', 'jobs', 'bg', 'fg'],
    'jaringan':     ['ping', 'ifconfig', 'curl', 'wget', 'ssh', 'netstat'],
    'arsip':        ['tar', 'zip', 'unzip', 'gzip', 'gunzip'],
    'disk':         ['df', 'du', 'mount', 'lsblk', 'fdisk'],
    'sistem':       ['uname', 'whoami', 'hostname', 'date', 'uptime', 'free', 'env', 'export', 'alias'],
    'teks':         ['sort', 'uniq', 'cut', 'awk', 'sed', 'diff', 'tr'],
    'paket':        ['apt', 'pkg', 'pip'],
    'lain':         ['clear', 'history', 'man', 'help', 'exit', 'sudo', 'su',
                     'bash', 'sh', 'source', 'xargs', 'yes', 'cal', 'bc',
                     'sleep', 'watch', 'crontab', 'passwd', 'id', 'groups'],
}

def dedent_tip(s):
    return textwrap.dedent(s).strip()

COMMAND_INFO = {
    # ── Navigasi ──
    'ls': {
        'desc': 'Menampilkan daftar file dan direktori.',
        'syntax': 'ls [opsi] [direktori]',
        'options': [
            ('-l',      'Format panjang: tampilkan permission, ukuran, tanggal'),
            ('-a',      'Tampilkan file tersembunyi (diawali titik)'),
            ('-la/-al', 'Gabungan -l dan -a'),
            ('-h',      'Ukuran file dalam format human-readable (K, M, G)'),
            ('-R',      'Rekursif: tampilkan isi semua subdirektori'),
            ('-t',      'Urutkan berdasarkan waktu modifikasi'),
            ('-S',      'Urutkan berdasarkan ukuran file'),
            ('-r',      'Balik urutan tampilan'),
        ],
        'examples': [
            ('ls',               'Tampilkan isi direktori saat ini'),
            ('ls -l',            'Tampilkan detail lengkap'),
            ('ls -la',           'Tampilkan semua file termasuk tersembunyi'),
            ('ls -lh',           'Tampilkan dengan ukuran file yang mudah dibaca'),
            ('ls documents',     'Tampilkan isi folder documents'),
            ('ls -la /etc',      'Tampilkan semua file di /etc'),
        ],
        'tips': 'Gunakan "ls -la" untuk melihat hak akses dan file tersembunyi sekaligus.',
    },
    'pwd': {
        'desc': 'Print Working Directory — menampilkan path direktori saat ini.',
        'syntax': 'pwd',
        'options': [('-L', 'Tampilkan path logis (default)'), ('-P', 'Tampilkan path fisik (resolve symlink)')],
        'examples': [('pwd', 'Tampilkan direktori kerja saat ini')],
        'tips': 'pwd sangat berguna saat kamu bingung sedang berada di mana di dalam sistem file.',
    },
    'cd': {
        'desc': 'Change Directory — berpindah ke direktori lain.',
        'syntax': 'cd [direktori]',
        'options': [],
        'examples': [
            ('cd documents',        'Masuk ke folder documents'),
            ('cd ..',               'Naik satu level ke direktori induk'),
            ('cd ../..',            'Naik dua level sekaligus'),
            ('cd ~',                'Kembali ke direktori home'),
            ('cd /',                'Pergi ke direktori root'),
            ('cd -',                'Kembali ke direktori sebelumnya'),
            ('cd /home/user/projects', 'Pindah dengan path absolut'),
        ],
        'tips': '"cd" tanpa argumen = kembali ke home. "cd -" = undo perpindahan terakhir.',
    },
    'tree': {
        'desc': 'Menampilkan struktur direktori seperti pohon.',
        'syntax': 'tree [opsi] [direktori]',
        'options': [
            ('-L n',  'Batasi kedalaman tampilan sebanyak n level'),
            ('-a',    'Tampilkan file tersembunyi'),
            ('-d',    'Hanya tampilkan direktori'),
            ('-f',    'Tampilkan path lengkap setiap file'),
        ],
        'examples': [
            ('tree',              'Tampilkan seluruh struktur dari sini'),
            ('tree -L 2',         'Tampilkan 2 level saja'),
            ('tree -d',           'Hanya tampilkan folder'),
            ('tree projects',     'Tampilkan struktur folder projects'),
        ],
        'tips': 'tree belum terinstal secara default di banyak sistem. Instal dengan: apt install tree',
    },

    # ── File ──
    'touch': {
        'desc': 'Membuat file kosong baru atau memperbarui timestamp file yang sudah ada.',
        'syntax': 'touch [nama_file]',
        'options': [('-t', 'Set timestamp tertentu'), ('-m', 'Hanya update modification time')],
        'examples': [
            ('touch file.txt',              'Buat file kosong baru'),
            ('touch a.txt b.txt c.txt',     'Buat beberapa file sekaligus'),
            ('touch .gitkeep',              'Buat file tersembunyi'),
            ('touch "file dengan spasi.txt"','File dengan nama yang ada spasinya'),
        ],
        'tips': 'touch sering dipakai untuk membuat file placeholder atau "menyentuh" file agar timestamp-nya update.',
    },
    'mkdir': {
        'desc': 'Make Directory — membuat direktori (folder) baru.',
        'syntax': 'mkdir [opsi] [nama_direktori]',
        'options': [
            ('-p', 'Buat direktori beserta induknya sekaligus (parents)'),
            ('-v', 'Tampilkan pesan untuk setiap direktori yang dibuat'),
        ],
        'examples': [
            ('mkdir folder_baru',                    'Buat satu folder'),
            ('mkdir a b c',                          'Buat banyak folder sekaligus'),
            ('mkdir -p a/b/c',                       'Buat folder bersarang (nested)'),
            ('mkdir -p projects/web/assets/images',  'Buat struktur folder sekaligus'),
        ],
        'tips': 'Gunakan mkdir -p untuk membuat struktur folder langsung sekaligus tanpa error.',
    },
    'cp': {
        'desc': 'Copy — menyalin file atau direktori.',
        'syntax': 'cp [opsi] sumber tujuan',
        'options': [
            ('-r/-R', 'Rekursif: salin direktori beserta isinya'),
            ('-v',    'Verbose: tampilkan proses penyalinan'),
            ('-i',    'Tanya konfirmasi sebelum menimpa file'),
            ('-n',    'Jangan timpa file yang sudah ada'),
            ('-p',    'Pertahankan permission dan timestamp'),
        ],
        'examples': [
            ('cp file.txt salinan.txt',            'Salin file ke nama baru'),
            ('cp file.txt documents/',             'Salin file ke folder lain'),
            ('cp -r projects/ backup_projects/',   'Salin seluruh folder'),
            ('cp -rv source/ dest/',               'Salin dengan tampilan verbose'),
            ('cp *.txt arsip/',                    'Salin semua file .txt ke arsip/'),
        ],
        'tips': 'Selalu gunakan -r saat menyalin direktori. Tanpa -r, cp tidak bisa salin folder.',
    },
    'mv': {
        'desc': 'Move — memindahkan atau mengganti nama file/direktori.',
        'syntax': 'mv [opsi] sumber tujuan',
        'options': [
            ('-i', 'Tanya konfirmasi sebelum menimpa'),
            ('-n', 'Jangan timpa file yang sudah ada'),
            ('-v', 'Verbose: tampilkan proses pemindahan'),
        ],
        'examples': [
            ('mv lama.txt baru.txt',         'Ganti nama file'),
            ('mv file.txt documents/',       'Pindahkan file ke folder lain'),
            ('mv folder/ /tmp/',             'Pindahkan folder ke /tmp'),
            ('mv -v *.log logs/',            'Pindahkan semua .log ke folder logs/'),
        ],
        'tips': 'mv bisa dipakai untuk rename (ganti nama) sekaligus memindahkan file.',
    },
    'rm': {
        'desc': 'Remove — menghapus file atau direktori. HATI-HATI: tidak ada recycle bin!',
        'syntax': 'rm [opsi] file/direktori',
        'options': [
            ('-r/-R', 'Rekursif: hapus direktori beserta isinya'),
            ('-f',    'Force: paksa hapus tanpa konfirmasi'),
            ('-i',    'Tanya konfirmasi sebelum menghapus'),
            ('-v',    'Verbose: tampilkan apa yang dihapus'),
        ],
        'examples': [
            ('rm file.txt',           'Hapus satu file'),
            ('rm a.txt b.txt',        'Hapus beberapa file sekaligus'),
            ('rm -r folder/',         'Hapus folder beserta isinya'),
            ('rm -rf folder/',        'Hapus paksa tanpa konfirmasi (HATI-HATI!)'),
            ('rm *.tmp',              'Hapus semua file berekstensi .tmp'),
            ('rm -i *.log',           'Hapus dengan konfirmasi satu per satu'),
        ],
        'tips': '  PERINGATAN: rm -rf sangat berbahaya! File yang dihapus tidak bisa dikembalikan. Selalu cek dua kali sebelum menjalankan!',
    },
    'rename': {
        'desc': 'Mengganti nama banyak file sekaligus menggunakan pola.',
        'syntax': "rename 's/lama/baru/' file*",
        'options': [],
        'examples': [
            ("rename 's/.txt/.md/' *.txt",     'Ganti ekstensi semua .txt menjadi .md'),
            ("rename 's/file/dokumen/' file*", 'Ganti awalan nama file'),
        ],
        'tips': 'rename menggunakan ekspresi reguler Perl. Lebih powerful dari mv untuk batch rename.',
    },

    # ── Isi File ──
    'cat': {
        'desc': 'Concatenate — menampilkan isi file ke layar.',
        'syntax': 'cat [opsi] [file]',
        'options': [
            ('-n', 'Tampilkan nomor baris'),
            ('-A', 'Tampilkan karakter tak terlihat (tab, newline, dll)'),
            ('-s', 'Rapikan baris kosong yang berulang'),
        ],
        'examples': [
            ('cat file.txt',           'Tampilkan isi file'),
            ('cat -n file.txt',        'Tampilkan dengan nomor baris'),
            ('cat file1.txt file2.txt','Tampilkan dua file sekaligus'),
            ('cat > baru.txt',         'Buat file baru dan ketik isinya (Ctrl+D untuk selesai)'),
            ('cat file1.txt >> file2.txt', 'Tambahkan isi file1 ke akhir file2'),
        ],
        'tips': 'Untuk file panjang, gunakan "more" atau "less" agar bisa di-scroll.',
    },
    'head': {
        'desc': 'Menampilkan N baris pertama dari file.',
        'syntax': 'head [opsi] file',
        'options': [('-n N', 'Tampilkan N baris pertama (default: 10)'), ('-c N', 'Tampilkan N byte pertama')],
        'examples': [
            ('head file.txt',        'Tampilkan 10 baris pertama'),
            ('head -n 5 file.txt',   'Tampilkan 5 baris pertama'),
            ('head -n 1 file.txt',   'Tampilkan baris pertama saja'),
        ],
        'tips': 'head berguna untuk mengintip isi file besar tanpa harus membuka semuanya.',
    },
    'tail': {
        'desc': 'Menampilkan N baris terakhir dari file.',
        'syntax': 'tail [opsi] file',
        'options': [
            ('-n N',  'Tampilkan N baris terakhir (default: 10)'),
            ('-f',    'Follow: pantau file secara real-time (cocok untuk log)'),
            ('-c N',  'Tampilkan N byte terakhir'),
        ],
        'examples': [
            ('tail file.txt',           'Tampilkan 10 baris terakhir'),
            ('tail -n 20 file.txt',     'Tampilkan 20 baris terakhir'),
            ('tail -f /var/log/syslog', 'Pantau log secara real-time'),
        ],
        'tips': '"tail -f" sangat berguna untuk memantau file log yang terus diperbarui.',
    },
    'more': {
        'desc': 'Menampilkan isi file halaman per halaman.',
        'syntax': 'more [file]',
        'options': [],
        'examples': [
            ('more file.txt',  'Buka file mode halaman'),
            ('ls -la | more',  'Pipe output ls ke more'),
        ],
        'tips': 'Tekan SPASI untuk halaman berikut, Q untuk keluar, /kata untuk mencari.',
    },
    'wc': {
        'desc': 'Word Count — menghitung baris, kata, dan karakter dalam file.',
        'syntax': 'wc [opsi] file',
        'options': [('-l', 'Hitung baris saja'), ('-w', 'Hitung kata saja'), ('-c', 'Hitung byte/karakter')],
        'examples': [
            ('wc file.txt',       'Tampilkan baris, kata, dan karakter'),
            ('wc -l file.txt',    'Hitung jumlah baris saja'),
            ('wc -w file.txt',    'Hitung jumlah kata saja'),
            ('ls | wc -l',        'Hitung jumlah file dalam direktori'),
        ],
        'tips': 'wc -l sering dipakai untuk mengetahui berapa baris kode dalam file.',
    },
    'echo': {
        'desc': 'Menampilkan teks ke layar atau menulis teks ke file.',
        'syntax': 'echo [opsi] [teks]',
        'options': [('-n', 'Jangan tambah newline di akhir'), ('-e', 'Aktifkan escape characters (\\n, \\t, dll)')],
        'examples': [
            ('echo Halo Dunia',            'Cetak teks ke layar'),
            ('echo "Halo $(whoami)"',      'Cetak dengan hasil perintah'),
            ('echo Halo > file.txt',       'Tulis teks ke file (timpa)'),
            ('echo Baris baru >> file.txt','Tambahkan teks ke akhir file'),
            ('echo -e "Baris1\\nBaris2"',  'Cetak dengan newline'),
            ('echo $HOME',                 'Tampilkan nilai variabel lingkungan'),
        ],
        'tips': '> menimpa isi file, >> menambahkan ke akhir file. Hati-hati dengan perbedaannya!',
    },
    'tee': {
        'desc': 'Membaca dari stdin dan menulis ke stdout sekaligus ke file.',
        'syntax': 'perintah | tee [opsi] file',
        'options': [('-a', 'Append: tambahkan ke file, jangan timpa')],
        'examples': [
            ('ls -la | tee output.txt',    'Tampilkan dan simpan output ls'),
            ('echo Halo | tee -a log.txt', 'Tampilkan dan tambahkan ke log'),
        ],
        'tips': 'tee berguna saat kamu ingin melihat output sekaligus menyimpannya ke file.',
    },

    # ── Cari ──
    'grep': {
        'desc': 'Global Regular Expression Print — mencari pola teks dalam file.',
        'syntax': 'grep [opsi] pola [file]',
        'options': [
            ('-i',  'Abaikan huruf besar/kecil (case-insensitive)'),
            ('-r',  'Rekursif: cari di semua file dalam direktori'),
            ('-n',  'Tampilkan nomor baris hasil pencarian'),
            ('-v',  'Invert: tampilkan baris yang TIDAK cocok'),
            ('-c',  'Hitung berapa baris yang cocok'),
            ('-l',  'Hanya tampilkan nama file yang cocok'),
            ('-w',  'Cocokkan kata utuh saja'),
            ('-A n','Tampilkan n baris setelah hasil'),
            ('-B n','Tampilkan n baris sebelum hasil'),
            ('-E',  'Gunakan extended regex'),
        ],
        'examples': [
            ('grep "error" log.txt',           'Cari kata "error" dalam file'),
            ('grep -i "error" log.txt',        'Cari tanpa peduli huruf besar/kecil'),
            ('grep -r "TODO" projects/',       'Cari "TODO" di semua file dalam folder'),
            ('grep -n "function" script.py',   'Cari dengan tampilkan nomor baris'),
            ('grep -v "^#" config.txt',        'Tampilkan baris yang bukan komentar'),
            ('grep -c "import" *.py',          'Hitung berapa kali "import" muncul'),
            ('ls | grep ".txt"',               'Filter output ls, hanya tampilkan .txt'),
        ],
        'tips': 'grep adalah salah satu perintah paling sering dipakai di Linux. Kuasai ini!',
    },
    'find': {
        'desc': 'Mencari file dan direktori berdasarkan berbagai kriteria.',
        'syntax': 'find [lokasi] [kondisi] [aksi]',
        'options': [
            ('-name "pola"',   'Cari berdasarkan nama (case-sensitive)'),
            ('-iname "pola"',  'Cari berdasarkan nama (case-insensitive)'),
            ('-type f',        'Hanya cari file biasa'),
            ('-type d',        'Hanya cari direktori'),
            ('-size +NM',      'Cari file lebih besar dari N MB'),
            ('-mtime -N',      'Cari file dimodifikasi kurang dari N hari lalu'),
            ('-perm 644',      'Cari file dengan permission tertentu'),
            ('-empty',         'Cari file atau direktori yang kosong'),
        ],
        'examples': [
            ('find . -name "*.txt"',              'Cari semua file .txt dari sini'),
            ('find /home -name "*.py"',           'Cari semua file Python di /home'),
            ('find . -type d',                    'Cari semua direktori'),
            ('find . -type f -empty',             'Cari file yang kosong'),
            ('find . -name "*.log" -mtime +7',    'Cari file .log lebih dari 7 hari lalu'),
            ('find / -name "passwd" -type f',     'Cari file bernama passwd'),
            ('find . -size +1M',                  'Cari file berukuran > 1MB'),
        ],
        'tips': 'find sangat powerful. Kombinasikan dengan -exec untuk langsung memproses hasil pencarian.',
    },
    'locate': {
        'desc': 'Mencari file menggunakan database index (lebih cepat dari find).',
        'syntax': 'locate [opsi] nama_file',
        'options': [('-i', 'Case-insensitive'), ('-n N', 'Batasi N hasil pertama')],
        'examples': [
            ('locate file.txt',      'Cari file bernama file.txt'),
            ('locate -i "*.PDF"',    'Cari file PDF tanpa peduli huruf besar'),
            ('locate passwd',        'Cari semua file bernama passwd'),
        ],
        'tips': 'locate perlu database yang diperbarui dengan "updatedb". Lebih cepat dari find tapi mungkin tidak up-to-date.',
    },
    'which': {
        'desc': 'Menampilkan lokasi executable dari suatu perintah.',
        'syntax': 'which perintah',
        'options': [('-a', 'Tampilkan semua lokasi, bukan hanya yang pertama')],
        'examples': [
            ('which python3', 'Di mana python3 terinstal?'),
            ('which bash',    'Di mana bash berada?'),
            ('which ls',      'Path lengkap perintah ls'),
        ],
        'tips': 'Gunakan which untuk memastikan versi program mana yang akan dijalankan.',
    },

    # ── Permission ──
    'chmod': {
        'desc': 'Change Mode — mengubah hak akses (permission) file atau direktori.',
        'syntax': 'chmod [opsi] mode file',
        'options': [
            ('-R',  'Rekursif: ubah permission semua file dalam direktori'),
            ('-v',  'Verbose: tampilkan perubahan yang dilakukan'),
        ],
        'examples': [
            ('chmod 755 script.sh',         'Beri izin rwxr-xr-x'),
            ('chmod 644 file.txt',          'Beri izin rw-r--r--'),
            ('chmod +x script.sh',          'Tambahkan izin execute untuk semua'),
            ('chmod -w file.txt',           'Hapus izin write untuk semua'),
            ('chmod u+x,g-w file.txt',      'Tambah execute untuk owner, hapus write untuk group'),
            ('chmod -R 755 folder/',        'Ubah permission semua file dalam folder'),
            ('chmod 777 file.txt',          'Izin penuh untuk semua (HATI-HATI!)'),
        ],
        'tips': dedent_tip('''
Permission dalam angka (oktal):
  r=4, w=2, x=1
  7=rwx, 6=rw-, 5=r-x, 4=r--, 0=---
  Digit 1=owner, Digit 2=group, Digit 3=others
  Contoh: 755 = rwxr-xr-x
        '''),
    },
    'chown': {
        'desc': 'Change Owner — mengubah pemilik file atau direktori.',
        'syntax': 'chown [opsi] pemilik[:group] file',
        'options': [('-R', 'Rekursif'), ('-v', 'Verbose')],
        'examples': [
            ('chown user file.txt',          'Ubah pemilik menjadi user'),
            ('chown user:group file.txt',    'Ubah pemilik dan group'),
            ('chown -R user folder/',        'Ubah pemilik semua isi folder'),
        ],
        'tips': 'chown biasanya memerlukan sudo/root untuk dijalankan.',
    },
    'stat': {
        'desc': 'Menampilkan status dan informasi detail file.',
        'syntax': 'stat file',
        'options': [],
        'examples': [
            ('stat file.txt',        'Tampilkan info lengkap file'),
            ('stat -c "%n %s" *.txt','Format: nama dan ukuran semua .txt'),
        ],
        'tips': 'stat menampilkan permission, ukuran, inode, dan waktu akses/modifikasi file.',
    },
    'umask': {
        'desc': 'Mengatur/menampilkan mask permission default untuk file baru.',
        'syntax': 'umask [nilai]',
        'options': [],
        'examples': [
            ('umask',       'Tampilkan nilai umask saat ini'),
            ('umask 022',   'Set umask ke 022 (file baru: 644, dir baru: 755)'),
            ('umask 027',   'File baru: 640, dir baru: 750'),
        ],
        'tips': 'umask bekerja kebalikan dari chmod. umask 022 berarti kurangi 022 dari 666 (file) = 644.',
    },

    # ── Proses ──
    'ps': {
        'desc': 'Process Status — menampilkan daftar proses yang sedang berjalan.',
        'syntax': 'ps [opsi]',
        'options': [
            ('aux',   'Tampilkan semua proses semua user dengan detail'),
            ('-ef',   'Tampilkan semua proses (format berbeda)'),
            ('-u user','Tampilkan proses milik user tertentu'),
        ],
        'examples': [
            ('ps',              'Tampilkan proses di terminal ini'),
            ('ps aux',          'Tampilkan semua proses secara detail'),
            ('ps aux | grep python', 'Cari proses Python'),
            ('ps -ef',          'Tampilkan semua proses full format'),
        ],
        'tips': 'Kolom penting: PID (nomor proses), %CPU, %MEM, COMMAND (nama program).',
    },
    'top': {
        'desc': 'Menampilkan proses yang berjalan secara real-time (mirip Task Manager).',
        'syntax': 'top',
        'options': [],
        'examples': [('top', 'Buka monitor proses real-time')],
        'tips': 'Di dalam top: Q=keluar, K=kill proses, M=urutkan memori, P=urutkan CPU.',
    },
    'kill': {
        'desc': 'Mengirim sinyal ke proses (biasanya untuk menghentikannya).',
        'syntax': 'kill [sinyal] PID',
        'options': [
            ('-9',   'SIGKILL: paksa hentikan proses (tidak bisa diabaikan)'),
            ('-15',  'SIGTERM: minta proses berhenti dengan baik (default)'),
            ('-l',   'Daftar semua sinyal yang tersedia'),
        ],
        'examples': [
            ('kill 1234',     'Kirim SIGTERM ke proses PID 1234'),
            ('kill -9 1234',  'Paksa hentikan proses PID 1234'),
            ('killall python', 'Hentikan semua proses bernama python'),
        ],
        'tips': 'Dapatkan PID dengan "ps aux | grep nama_program". Coba kill biasa dulu sebelum kill -9.',
    },
    'jobs': {
        'desc': 'Menampilkan daftar pekerjaan (job) di background/foreground.',
        'syntax': 'jobs [opsi]',
        'options': [('-l', 'Tampilkan PID')],
        'examples': [('jobs', 'Lihat semua job saat ini')],
        'tips': 'Job dibuat dengan Ctrl+Z (suspend) atau menjalankan program dengan & di akhir.',
    },
    'bg': {
        'desc': 'Melanjutkan job yang ter-suspend di background.',
        'syntax': 'bg [%job_number]',
        'options': [],
        'examples': [('bg', 'Lanjutkan job terakhir di background'), ('bg %2', 'Lanjutkan job nomor 2')],
        'tips': 'Gunakan setelah Ctrl+Z untuk suspend, lalu bg untuk lanjutkan di background.',
    },
    'fg': {
        'desc': 'Memindahkan job dari background ke foreground.',
        'syntax': 'fg [%job_number]',
        'options': [],
        'examples': [('fg', 'Ambil job background ke foreground'), ('fg %1', 'Ambil job nomor 1')],
        'tips': 'bg dan fg adalah cara dasar multitasking di terminal Linux.',
    },

    # ── Jaringan ──
    'ping': {
        'desc': 'Menguji koneksi jaringan ke host tertentu.',
        'syntax': 'ping [opsi] host',
        'options': [('-c N', 'Kirim N paket saja'), ('-i N', 'Interval N detik antar paket')],
        'examples': [
            ('ping google.com',       'Tes koneksi ke Google'),
            ('ping -c 4 8.8.8.8',    'Kirim 4 paket ke DNS Google'),
            ('ping localhost',         'Tes loopback (koneksi lokal)'),
        ],
        'tips': 'Jika ping timeout, kemungkinan tidak ada koneksi internet atau host tersebut memblokir ICMP.',
    },
    'ifconfig': {
        'desc': 'Menampilkan atau mengonfigurasi antarmuka jaringan.',
        'syntax': 'ifconfig [antarmuka] [opsi]',
        'options': [],
        'examples': [
            ('ifconfig',          'Tampilkan semua antarmuka jaringan'),
            ('ifconfig eth0',     'Info antarmuka eth0'),
            ('ifconfig wlan0',    'Info WiFi'),
        ],
        'tips': 'Di sistem modern, gunakan "ip addr" atau "ip a" sebagai pengganti ifconfig.',
    },
    'curl': {
        'desc': 'Client URL — mengunduh atau mengirim data ke/dari URL.',
        'syntax': 'curl [opsi] URL',
        'options': [
            ('-O',    'Unduh file dengan nama aslinya'),
            ('-o nama','Unduh dengan nama tertentu'),
            ('-L',    'Ikuti redirect'),
            ('-s',    'Silent mode'),
            ('-I',    'Tampilkan header saja'),
            ('-d',    'Kirim data POST'),
            ('-H',    'Tambah header HTTP'),
        ],
        'examples': [
            ('curl https://example.com',                'Ambil halaman web'),
            ('curl -O https://example.com/file.zip',   'Unduh file'),
            ('curl -s https://api.github.com/users/x', 'Akses API'),
            ('curl -I https://google.com',             'Tampilkan header HTTP saja'),
        ],
        'tips': 'curl adalah alat yang sangat berguna untuk testing API dan mengunduh file di terminal.',
    },
    'wget': {
        'desc': 'Web Get — mengunduh file dari internet.',
        'syntax': 'wget [opsi] URL',
        'options': [
            ('-O nama',     'Simpan dengan nama tertentu'),
            ('-c',          'Lanjutkan unduhan yang terputus'),
            ('-r',          'Unduh rekursif (seluruh website)'),
            ('-q',          'Quiet mode (tanpa output)'),
            ('--limit-rate', 'Batasi kecepatan unduhan'),
        ],
        'examples': [
            ('wget https://example.com/file.zip',          'Unduh file'),
            ('wget -O output.zip https://example.com/file','Unduh dengan nama baru'),
            ('wget -c https://example.com/bigfile.iso',    'Lanjutkan unduhan terputus'),
        ],
        'tips': 'wget lebih simpel dari curl untuk mengunduh file. curl lebih fleksibel untuk API.',
    },
    'ssh': {
        'desc': 'Secure Shell — koneksi remote yang aman ke server lain.',
        'syntax': 'ssh [opsi] user@host',
        'options': [
            ('-p N',  'Gunakan port N'),
            ('-i key','Gunakan file kunci privat'),
            ('-L',    'Local port forwarding'),
            ('-v',    'Verbose/debug mode'),
        ],
        'examples': [
            ('ssh user@192.168.1.100',         'Koneksi ke server lokal'),
            ('ssh user@server.com',            'Koneksi ke server dengan domain'),
            ('ssh -p 2222 user@server.com',    'Koneksi ke port non-standar'),
            ('ssh-keygen -t rsa',              'Buat pasangan kunci SSH'),
        ],
        'tips': 'Gunakan SSH key (ssh-keygen) daripada password untuk keamanan lebih baik.',
    },

    # ── Arsip ──
    'tar': {
        'desc': 'Tape Archive — membuat atau mengekstrak arsip file.',
        'syntax': 'tar [opsi] arsip.tar [file/folder]',
        'options': [
            ('-c', 'Create: buat arsip baru'),
            ('-x', 'eXtract: ekstrak arsip'),
            ('-t', 'lisT: tampilkan isi arsip tanpa ekstrak'),
            ('-v', 'Verbose: tampilkan proses'),
            ('-f', 'File: tentukan nama file arsip (wajib)'),
            ('-z', 'gZip: kompresi/dekompresi gzip (.tar.gz)'),
            ('-j', 'bzip2: kompresi/dekompresi bzip2 (.tar.bz2)'),
            ('-J', 'xz: kompresi/dekompresi xz (.tar.xz)'),
        ],
        'examples': [
            ('tar -cvf arsip.tar folder/',              'Buat arsip dari folder'),
            ('tar -czvf arsip.tar.gz folder/',          'Buat arsip terkompresi gzip'),
            ('tar -xzvf arsip.tar.gz',                  'Ekstrak arsip .tar.gz'),
            ('tar -tvf arsip.tar',                      'Lihat isi arsip tanpa ekstrak'),
            ('tar -xzvf arsip.tar.gz -C /tmp/',         'Ekstrak ke folder /tmp'),
        ],
        'tips': 'Hafal ini: c=buat, x=ekstrak, z=gzip, v=verbose, f=file. "cvf" = buat, "xvf" = ekstrak.',
    },
    'zip': {
        'desc': 'Membuat file arsip .zip.',
        'syntax': 'zip [opsi] arsip.zip file/folder',
        'options': [('-r', 'Rekursif: sertakan subdirektori'), ('-9', 'Kompresi maksimal'), ('-e', 'Enkripsi dengan password')],
        'examples': [
            ('zip arsip.zip file.txt',           'Buat zip dari satu file'),
            ('zip -r arsip.zip folder/',         'Buat zip dari folder'),
            ('zip -r arsip.zip *.txt',           'Buat zip dari semua .txt'),
            ('zip -re rahasia.zip folder/',      'Buat zip terenkripsi'),
        ],
        'tips': 'zip lebih kompatibel lintas platform (Windows/Mac/Linux) dibanding tar.',
    },
    'unzip': {
        'desc': 'Mengekstrak file .zip.',
        'syntax': 'unzip [opsi] arsip.zip',
        'options': [('-d folder', 'Ekstrak ke folder tertentu'), ('-l', 'Daftar isi tanpa ekstrak'), ('-o', 'Overwrite tanpa tanya')],
        'examples': [
            ('unzip arsip.zip',                 'Ekstrak di direktori saat ini'),
            ('unzip arsip.zip -d /tmp/',        'Ekstrak ke /tmp'),
            ('unzip -l arsip.zip',              'Lihat isi zip tanpa ekstrak'),
        ],
        'tips': 'Selalu cek isi zip dengan -l sebelum mengekstrak untuk menghindari zip bomb.',
    },
    'gzip': {
        'desc': 'Kompresi file menggunakan algoritma gzip.',
        'syntax': 'gzip [opsi] file',
        'options': [('-k', 'Pertahankan file asli'), ('-d', 'Dekompresi (sama dengan gunzip)'), ('-9', 'Kompresi maksimal')],
        'examples': [
            ('gzip file.txt',       'Kompresi file menjadi file.txt.gz'),
            ('gzip -k file.txt',    'Kompresi tapi simpan file asli'),
            ('gzip -d file.txt.gz', 'Dekompresi file'),
        ],
        'tips': 'gzip hanya bisa kompresi satu file. Untuk banyak file, gunakan tar dulu.',
    },

    # ── Disk ──
    'df': {
        'desc': 'Disk Free — menampilkan penggunaan ruang disk.',
        'syntax': 'df [opsi] [filesystem]',
        'options': [('-h', 'Human-readable: tampilkan dalam K/M/G'), ('-T', 'Tampilkan tipe filesystem')],
        'examples': [
            ('df -h',        'Tampilkan penggunaan disk semua partisi'),
            ('df -h /home',  'Cek ruang disk di /home'),
            ('df -Th',       'Tampilkan dengan tipe filesystem'),
        ],
        'tips': 'Perhatikan kolom "Use%" — jika sudah di atas 90%, segera bersihkan disk!',
    },
    'du': {
        'desc': 'Disk Usage — menghitung ukuran file/direktori.',
        'syntax': 'du [opsi] [file/direktori]',
        'options': [
            ('-h', 'Human-readable'),
            ('-s', 'Summary: tampilkan total saja'),
            ('-a', 'Tampilkan semua file juga'),
            ('--max-depth=N', 'Batasi kedalaman N level'),
        ],
        'examples': [
            ('du -sh folder/',          'Total ukuran folder'),
            ('du -h --max-depth=1',     'Ukuran tiap subfolder'),
            ('du -sh *',                'Ukuran semua item di sini'),
            ('du -sh * | sort -h',      'Urutkan berdasarkan ukuran'),
        ],
        'tips': '"du -sh * | sort -rh | head" adalah cara cepat mencari file/folder terbesar.',
    },

    # ── Sistem ──
    'uname': {
        'desc': 'Menampilkan informasi sistem operasi.',
        'syntax': 'uname [opsi]',
        'options': [('-a', 'Semua informasi'), ('-r', 'Versi kernel'), ('-m', 'Arsitektur mesin'), ('-n', 'Nama host')],
        'examples': [
            ('uname -a',  'Tampilkan semua info sistem'),
            ('uname -r',  'Versi kernel Linux'),
            ('uname -m',  'Arsitektur (x86_64, arm64, dll)'),
        ],
        'tips': '"uname -a" adalah cara cepat melihat info dasar sistem operasi.',
    },
    'whoami': {
        'desc': 'Menampilkan nama user yang sedang login.',
        'syntax': 'whoami',
        'options': [],
        'examples': [('whoami', 'Tampilkan nama user saat ini')],
        'tips': 'Berguna di skrip untuk mengecek apakah dijalankan sebagai root.',
    },
    'hostname': {
        'desc': 'Menampilkan atau mengubah nama host komputer.',
        'syntax': 'hostname [nama_baru]',
        'options': [('-I', 'Tampilkan semua IP address')],
        'examples': [('hostname', 'Tampilkan nama host'), ('hostname -I', 'Tampilkan IP address')],
        'tips': 'Nama host adalah nama komputer/server di dalam jaringan.',
    },
    'date': {
        'desc': 'Menampilkan atau mengatur tanggal dan waktu sistem.',
        'syntax': 'date [+format]',
        'options': [],
        'examples': [
            ('date',                 'Tampilkan tanggal dan waktu saat ini'),
            ('date +"%Y-%m-%d"',     'Format: 2024-01-15'),
            ('date +"%H:%M:%S"',     'Format: 08:30:00'),
            ('date +"%d %B %Y"',     'Format: 15 January 2024'),
        ],
        'tips': 'Format date berguna di shell script untuk memberi nama file dengan timestamp.',
    },
    'uptime': {
        'desc': 'Menampilkan sudah berapa lama sistem berjalan.',
        'syntax': 'uptime',
        'options': [],
        'examples': [('uptime', 'Tampilkan waktu nyala, jumlah user, dan load average')],
        'tips': 'Load average yang baik biasanya di bawah jumlah inti CPU.',
    },
    'free': {
        'desc': 'Menampilkan penggunaan memori (RAM dan swap).',
        'syntax': 'free [opsi]',
        'options': [('-h', 'Human-readable'), ('-m', 'Dalam MB'), ('-g', 'Dalam GB')],
        'examples': [('free -h', 'Tampilkan penggunaan RAM dalam format mudah dibaca')],
        'tips': 'Perhatikan kolom "available" — itu yang benar-benar tersedia untuk program baru.',
    },
    'env': {
        'desc': 'Menampilkan atau mengatur variabel lingkungan (environment variables).',
        'syntax': 'env [variabel=nilai] [perintah]',
        'options': [],
        'examples': [
            ('env',                   'Tampilkan semua variabel lingkungan'),
            ('env | grep PATH',       'Cari variabel PATH'),
            ('env VAR=nilai perintah','Jalankan perintah dengan variabel tertentu'),
        ],
        'tips': 'Variabel lingkungan penting: PATH, HOME, USER, SHELL, LANG, PWD.',
    },
    'export': {
        'desc': 'Menetapkan atau mengekspor variabel lingkungan ke proses anak.',
        'syntax': 'export VARIABEL=nilai',
        'options': [],
        'examples': [
            ('export PATH=$PATH:/opt/bin', 'Tambahkan /opt/bin ke PATH'),
            ('export EDITOR=nano',         'Set editor default ke nano'),
            ('export MY_VAR="Halo"',       'Buat variabel sendiri'),
        ],
        'tips': 'Variabel yang di-export akan diwariskan ke program yang dijalankan dari shell tersebut.',
    },
    'alias': {
        'desc': 'Membuat alias (pintasan) untuk perintah yang panjang.',
        'syntax': "alias nama='perintah'",
        'options': [],
        'examples': [
            ('alias',                        'Tampilkan semua alias yang ada'),
            ("alias ll='ls -la'",            'Buat alias ll untuk ls -la'),
            ("alias update='apt update && apt upgrade'", 'Alias untuk update sistem'),
            ('unalias ll',                   'Hapus alias ll'),
        ],
        'tips': "Tambahkan alias ke ~/.bashrc agar permanen. Gunakan tanda kutip tunggal ' untuk alias.",
    },

    # ── Teks ──
    'sort': {
        'desc': 'Mengurutkan baris teks dalam file.',
        'syntax': 'sort [opsi] [file]',
        'options': [
            ('-r', 'Reverse: urutan terbalik'),
            ('-n', 'Numerik: urutkan sebagai angka'),
            ('-k N', 'Urutkan berdasarkan kolom ke-N'),
            ('-u', 'Unique: hapus duplikat'),
            ('-h', 'Human-readable: urutkan K, M, G dengan benar'),
        ],
        'examples': [
            ('sort file.txt',          'Urutkan baris alfabet'),
            ('sort -r file.txt',       'Urutkan terbalik'),
            ('sort -n angka.txt',      'Urutkan secara numerik'),
            ('ls -s | sort -rn',       'Urutkan file berdasarkan ukuran'),
        ],
        'tips': 'sort -u menghapus duplikat sambil mengurutkan, lebih efisien dari sort | uniq.',
    },
    'uniq': {
        'desc': 'Menghilangkan atau melaporkan baris yang duplikat.',
        'syntax': 'uniq [opsi] [file]',
        'options': [('-c', 'Hitung kemunculan'), ('-d', 'Hanya tampilkan duplikat'), ('-u', 'Hanya tampilkan yang unik')],
        'examples': [
            ('sort file.txt | uniq',      'Hilangkan duplikat (perlu sort dulu)'),
            ('sort file.txt | uniq -c',   'Hitung kemunculan setiap baris'),
            ('sort file.txt | uniq -d',   'Tampilkan hanya baris yang duplikat'),
        ],
        'tips': 'uniq hanya mendeteksi duplikat yang berurutan. Selalu sort dulu sebelum uniq!',
    },
    'cut': {
        'desc': 'Mengambil bagian (kolom) tertentu dari setiap baris teks.',
        'syntax': 'cut [opsi] file',
        'options': [
            ('-d delim', 'Tentukan delimiter (pemisah kolom)'),
            ('-f N',     'Ambil kolom ke-N'),
            ('-c N',     'Ambil karakter ke-N'),
        ],
        'examples': [
            ('cut -d":" -f1 /etc/passwd',  'Ambil kolom pertama (username)'),
            ('cut -d"," -f2 data.csv',     'Ambil kolom ke-2 dari CSV'),
            ('cut -c1-10 file.txt',        'Ambil 10 karakter pertama setiap baris'),
        ],
        'tips': 'cut bagus untuk parsing file CSV atau output yang terstruktur dengan delimiter.',
    },
    'awk': {
        'desc': 'Bahasa pemrograman mini untuk memproses teks terstruktur.',
        'syntax': "awk 'pola {aksi}' file",
        'options': [('-F delim', 'Tentukan field separator'), ('-v var=val', 'Set variabel')],
        'examples': [
            ("awk '{print $1}' file.txt",       'Cetak kolom pertama'),
            ("awk -F: '{print $1}' /etc/passwd",'Cetak username dari passwd'),
            ("awk '{sum+=$1} END{print sum}' f",'Jumlahkan kolom pertama'),
            ("awk 'NR==5' file.txt",            'Cetak baris ke-5'),
            ("awk '$2>100{print}' data.txt",    'Cetak baris di mana kolom 2 > 100'),
        ],
        'tips': 'awk adalah tool yang sangat powerful. $1, $2 = kolom 1, 2. $0 = seluruh baris. NR = nomor baris.',
    },
    'sed': {
        'desc': 'Stream EDitor — mengedit teks secara otomatis (cari dan ganti).',
        'syntax': "sed 'perintah' file",
        'options': [('-i', 'In-place: edit file langsung'), ('-n', 'Jangan cetak kecuali diminta')],
        'examples': [
            ("sed 's/lama/baru/' file.txt",      'Ganti kemunculan pertama per baris'),
            ("sed 's/lama/baru/g' file.txt",     'Ganti semua kemunculan'),
            ("sed -i 's/foo/bar/g' file.txt",    'Edit file langsung'),
            ("sed -n '5,10p' file.txt",          'Cetak baris 5-10'),
            ("sed '/^#/d' config.txt",           'Hapus baris komentar'),
        ],
        'tips': "sed 's/lama/baru/g' adalah yang paling sering dipakai. -i untuk edit file langsung.",
    },
    'diff': {
        'desc': 'Membandingkan dua file dan menampilkan perbedaannya.',
        'syntax': 'diff [opsi] file1 file2',
        'options': [('-u', 'Unified format (lebih mudah dibaca)'), ('-r', 'Rekursif: bandingkan dua direktori')],
        'examples': [
            ('diff file1.txt file2.txt',     'Bandingkan dua file'),
            ('diff -u file1.txt file2.txt',  'Format unified (lebih mudah dibaca)'),
            ('diff -r dir1/ dir2/',          'Bandingkan dua direktori'),
        ],
        'tips': 'Simbol "<" = dari file1, ">" = dari file2, "---" = pemisah. Baris dengan "+" ditambah, "-" dihapus.',
    },
    'tr': {
        'desc': 'Translate — mengganti atau menghapus karakter.',
        'syntax': 'tr [opsi] set1 [set2]',
        'options': [('-d', 'Delete: hapus karakter dalam set1'), ('-s', 'Squeeze: perkecil karakter berulang')],
        'examples': [
            ("echo 'halo' | tr 'a-z' 'A-Z'",  'Ubah ke huruf besar'),
            ("echo 'HALO' | tr 'A-Z' 'a-z'",  'Ubah ke huruf kecil'),
            ("echo 'ha  lo' | tr -s ' '",      'Hapus spasi berulang'),
            ("cat file.txt | tr -d '\\n'",     'Hapus semua newline'),
        ],
        'tips': 'tr tidak membaca file langsung, harus pakai pipe atau redirect.',
    },

    # ── Paket ──
    'apt': {
        'desc': 'Advanced Package Tool — manajemen paket di Debian/Ubuntu.',
        'syntax': 'apt [subperintah] [paket]',
        'options': [],
        'examples': [
            ('apt update',              'Perbarui daftar paket'),
            ('apt upgrade',             'Perbarui semua paket terinstal'),
            ('apt install nama_paket',  'Instal paket baru'),
            ('apt remove nama_paket',   'Hapus paket'),
            ('apt purge nama_paket',    'Hapus paket beserta konfigurasinya'),
            ('apt search kata_kunci',   'Cari paket berdasarkan kata kunci'),
            ('apt show nama_paket',     'Info detail paket'),
            ('apt list --installed',    'Daftar semua paket terinstal'),
        ],
        'tips': 'Selalu jalankan "apt update" sebelum "apt install" untuk mendapat versi terbaru.',
    },
    'pkg': {
        'desc': 'Package manager khusus untuk Termux di Android.',
        'syntax': 'pkg [subperintah] [paket]',
        'options': [],
        'examples': [
            ('pkg update',              'Perbarui daftar paket Termux'),
            ('pkg upgrade',             'Perbarui semua paket'),
            ('pkg install python',      'Instal Python'),
            ('pkg install git',         'Instal Git'),
            ('pkg install nano',        'Instal editor teks Nano'),
            ('pkg search cari',         'Cari paket'),
            ('pkg list-installed',      'Daftar paket terinstal'),
        ],
        'tips': 'pkg adalah wrapper apt yang dimodifikasi untuk Termux. pkg = apt di Termux.',
    },
    'pip': {
        'desc': 'Package Installer for Python — instal library Python.',
        'syntax': 'pip install [opsi] [paket]',
        'options': [],
        'examples': [
            ('pip install requests',              'Instal library requests'),
            ('pip install numpy pandas',          'Instal beberapa library sekaligus'),
            ('pip install -r requirements.txt',   'Instal dari file requirements'),
            ('pip list',                          'Daftar library terinstal'),
            ('pip show requests',                 'Info detail library'),
            ('pip uninstall requests',            'Hapus library'),
            ('pip freeze > requirements.txt',     'Simpan daftar dependensi'),
        ],
        'tips': 'Gunakan virtual environment (venv) untuk proyek Python agar library tidak bertabrakan.',
    },

    # ── Lain-lain ──
    'clear': {
        'desc': 'Membersihkan layar terminal.',
        'syntax': 'clear',
        'options': [],
        'examples': [('clear', 'Bersihkan layar')],
        'tips': 'Shortcut keyboard: Ctrl+L (lebih cepat dari mengetik clear).',
    },
    'history': {
        'desc': 'Menampilkan riwayat perintah yang pernah diketik.',
        'syntax': 'history [N]',
        'options': [('-c', 'Hapus semua history')],
        'examples': [
            ('history',         'Tampilkan semua riwayat'),
            ('history 20',      'Tampilkan 20 perintah terakhir'),
            ('history | grep ls','Cari perintah ls dalam history'),
            ('!42',             'Jalankan ulang perintah nomor 42'),
            ('!!',              'Jalankan ulang perintah terakhir'),
        ],
        'tips': 'Tekan panah atas/bawah untuk navigasi history. Ctrl+R untuk pencarian history.',
    },
    'man': {
        'desc': 'Manual — menampilkan dokumentasi lengkap suatu perintah.',
        'syntax': 'man [perintah]',
        'options': [('-k kata', 'Cari manual berdasarkan kata kunci')],
        'examples': [
            ('man ls',      'Baca manual ls'),
            ('man chmod',   'Baca manual chmod'),
            ('man -k copy', 'Cari semua manual yang berkaitan dengan "copy"'),
        ],
        'tips': "Di dalam man: Q=keluar, /kata=cari, n=hasil berikut. Atau coba perintah --help dulu.",
    },
    'sudo': {
        'desc': 'SuperUser DO — jalankan perintah dengan hak akses root/administrator.',
        'syntax': 'sudo [perintah]',
        'options': [('-u user', 'Jalankan sebagai user lain'), ('-i', 'Buka shell interaktif sebagai root')],
        'examples': [
            ('sudo apt update',          'Update dengan hak root'),
            ('sudo nano /etc/hosts',     'Edit file sistem'),
            ('sudo -i',                  'Masuk sebagai root'),
            ('sudo !!',                  'Ulangi perintah terakhir dengan sudo'),
        ],
        'tips': ' Gunakan sudo dengan hati-hati! Kesalahan dengan sudo bisa merusak sistem.',
    },
    'bash': {
        'desc': 'Menjalankan skrip shell Bash atau membuka shell baru.',
        'syntax': 'bash [file_skrip]',
        'options': [('-c "perintah"', 'Jalankan perintah langsung'), ('-x', 'Debug mode: tampilkan setiap perintah')],
        'examples': [
            ('bash script.sh',         'Jalankan skrip Bash'),
            ('bash -x script.sh',      'Jalankan dengan debug mode'),
            ('bash -c "echo Halo"',    'Jalankan perintah via bash'),
        ],
        'tips': 'Beri izin eksekusi dulu dengan chmod +x script.sh, lalu jalankan dengan ./script.sh',
    },
    'source': {
        'desc': 'Menjalankan skrip di shell saat ini (bukan sub-shell).',
        'syntax': 'source file  atau  . file',
        'options': [],
        'examples': [
            ('source ~/.bashrc',  'Reload konfigurasi bash'),
            ('. ~/.bashrc',       'Sama dengan source'),
            ('source script.sh',  'Jalankan skrip dan ambil variabelnya'),
        ],
        'tips': 'source berbeda dari bash: variabel yang di-set akan tetap ada di shell saat ini.',
    },
    'xargs': {
        'desc': 'Membangun dan menjalankan perintah dari standard input.',
        'syntax': 'xargs [opsi] perintah',
        'options': [('-I {}', 'Ganti {} dengan argumen'), ('-n N', 'N argumen per perintah'), ('-P N', 'N proses paralel')],
        'examples': [
            ('ls *.txt | xargs rm',              'Hapus semua .txt yang ditemukan ls'),
            ('find . -name "*.log" | xargs rm',  'Hapus semua .log yang ditemukan find'),
            ('cat list.txt | xargs mkdir',       'Buat folder dari daftar di file'),
            ('echo "a b c" | xargs -n1 echo',   'Proses satu per satu'),
        ],
        'tips': 'xargs sangat berguna untuk menjalankan perintah pada banyak file sekaligus.',
    },
    'cal': {
        'desc': 'Menampilkan kalender.',
        'syntax': 'cal [bulan] [tahun]',
        'options': [],
        'examples': [
            ('cal',         'Tampilkan kalender bulan ini'),
            ('cal 12 2024', 'Tampilkan Desember 2024'),
            ('cal 2024',    'Tampilkan kalender setahun penuh'),
        ],
        'tips': 'Hari ini ditandai dengan highlight/bold.',
    },
    'bc': {
        'desc': 'Basic Calculator — kalkulator di terminal.',
        'syntax': 'bc [opsi]',
        'options': [('-l', 'Aktifkan math library (sin, cos, dll)')],
        'examples': [
            ('echo "5+3" | bc',          'Hitung 5+3'),
            ('echo "scale=2; 10/3" | bc','Bagi dengan 2 desimal'),
            ('echo "sqrt(16)" | bc -l',  'Akar kuadrat 16'),
            ('echo "2^10" | bc',         '2 pangkat 10'),
        ],
        'tips': 'bc bisa juga dijalankan interaktif. Ketik quit untuk keluar.',
    },
    'sleep': {
        'desc': 'Menunda eksekusi selama N detik.',
        'syntax': 'sleep N[smhd]',
        'options': [],
        'examples': [
            ('sleep 5',     'Tunggu 5 detik'),
            ('sleep 1m',    'Tunggu 1 menit'),
            ('sleep 0.5',   'Tunggu 0.5 detik'),
        ],
        'tips': 'sleep sering dipakai dalam skrip: sleep 2 && echo "selesai"',
    },
    'passwd': {
        'desc': 'Mengubah password user.',
        'syntax': 'passwd [username]',
        'options': [],
        'examples': [
            ('passwd',          'Ubah password user saat ini'),
            ('sudo passwd root','Ubah password root'),
        ],
        'tips': 'Di Termux tidak ada password. passwd biasa dipakai di sistem Linux penuh.',
    },
    'id': {
        'desc': 'Menampilkan UID, GID, dan group milik user.',
        'syntax': 'id [username]',
        'options': [],
        'examples': [
            ('id',       'Info user saat ini'),
            ('id root',  'Info user root'),
        ],
        'tips': 'UID 0 berarti root (administrator). Cek dengan "id | grep uid=0" untuk tahu apakah kamu root.',
    },
    'groups': {
        'desc': 'Menampilkan grup yang diikuti user saat ini.',
        'syntax': 'groups [username]',
        'options': [],
        'examples': [('groups', 'Tampilkan semua grup user ini')],
        'tips': 'Anggota grup "sudo" dapat menjalankan perintah dengan sudo.',
    },
    'crontab': {
        'desc': 'Mengatur penjadwalan tugas otomatis (cron jobs).',
        'syntax': 'crontab [opsi]',
        'options': [('-l', 'Tampilkan jadwal saat ini'), ('-e', 'Edit jadwal'), ('-r', 'Hapus semua jadwal')],
        'examples': [
            ('crontab -l',  'Lihat jadwal cron'),
            ('crontab -e',  'Edit jadwal cron'),
        ],
        'tips': 'Format cron: menit jam hari bulan hari_minggu perintah\n  "0 * * * * /path/script.sh" = tiap jam tepat',
    },
    'watch': {
        'desc': 'Menjalankan perintah secara berulang dan menampilkan hasilnya.',
        'syntax': 'watch [opsi] perintah',
        'options': [('-n N', 'Update tiap N detik (default: 2)'), ('-d', 'Highlight perubahan')],
        'examples': [
            ('watch df -h',          'Pantau penggunaan disk tiap 2 detik'),
            ('watch -n 5 ps aux',    'Pantau proses tiap 5 detik'),
            ('watch -d free -m',     'Pantau memori, highlight perubahan'),
        ],
        'tips': 'Ctrl+C untuk keluar dari watch.',
    },
    'yes': {
        'desc': 'Mencetak "y" (atau teks tertentu) berulang-ulang.',
        'syntax': 'yes [teks]',
        'options': [],
        'examples': [
            ('yes | rm -i *.txt',  'Otomatis jawab y saat rm -i bertanya'),
            ('yes tidak',          'Cetak "tidak" terus menerus'),
        ],
        'tips': 'Ctrl+C untuk menghentikan yes.',
    },
    'su': {
        'desc': 'Switch User — berpindah ke user lain.',
        'syntax': 'su [opsi] [username]',
        'options': [('-', 'Login shell (muat environment user tujuan penuh)')],
        'examples': [
            ('su',          'Pindah ke root'),
            ('su - user2',  'Pindah ke user2 dengan environment penuh'),
        ],
        'tips': 'su berbeda dari sudo: su ganti identitas kamu, sudo jalankan satu perintah sebagai orang lain.',
    },
    'netstat': {
        'desc': 'Menampilkan koneksi jaringan, tabel routing, dan statistik antarmuka.',
        'syntax': 'netstat [opsi]',
        'options': [('-tuln', 'Tampilkan port TCP/UDP yang mendengarkan'), ('-p', 'Tampilkan nama program')],
        'examples': [
            ('netstat -tuln',         'Lihat port yang terbuka'),
            ('netstat -tulnp',        'Lihat port beserta programnya'),
            ('netstat -an | grep ESTABLISHED', 'Lihat koneksi aktif'),
        ],
        'tips': 'Di sistem modern, ss menggantikan netstat. Contoh: ss -tuln',
    },
}

# Patch tips yang butuh dedent
COMMAND_INFO['chmod']['tips'] = dedent_tip('''
Permission dalam angka (oktal):
  r=4, w=2, x=1;
  7=rwx, 6=rw-, 5=r-x, 4=r--, 0=---
  Digit 1=owner, Digit 2=group, Digit 3=others
  Contoh: 755 = rwxr-xr-x
''')

COMMAND_INFO['crontab']['tips'] = dedent_tip('''
Format cron: menit jam hari bulan hari_minggu perintah
  "0 * * * * script.sh" = jalankan tiap jam
  "0 8 * * 1 backup.sh" = tiap Senin jam 08:00
  "*/5 * * * * check.sh" = tiap 5 menit
''')

# ─── FUNGSI BANTUAN TAMPILAN ─────
def show_man(cmd_name):
    # deff ini untuk menampilkan halaman manual lengkap untuk satu perintah.
    info = COMMAND_INFO.get(cmd_name)
    if not info:
        print_error(f"Tidak ada dokumentasi untuk '{cmd_name}'.")
        print_info("Coba 'help' untuk melihat semua perintah yang tersedia.")
        return

    print(f"\n{Y}{'═'*68}{N}")
    print(f"{BOLD}{C}  PERINTAH: {W}{cmd_name.upper()}{N}")
    print(f"{Y}{'═'*68}{N}")

    print(f"\n{G} DESKRIPSI:{N}")
    print(f"   {W}{info['desc']}{N}")

    print(f"\n{G} SINTAKS:{N}")
    print(f"   {C}{info['syntax']}{N}")

    if info.get('options'):
        print(f"\n{G} OPSI:{N}")
        for opt, desc in info['options']:
            print(f"   {Y}{opt:<16}{N}{W}{desc}{N}")

    if info.get('examples'):
        print(f"\n{G} CONTOH PENGGUNAAN:{N}")
        for ex, desc in info['examples']:
            print(f"   {C}$ {ex}{N}")
            print(f"     {DG}→ {desc}{N}")

    if info.get('tips'):
        print(f"\n{G} TIPS & CATATAN:{N}")
        for line in info['tips'].split('\n'):
            print(f"   {Y}{line}{N}")

    print(f"\n{Y}{'═'*68}{N}\n")

def show_help_main():
    # deff ini untuk menampilkan halaman help utama.
    print(f"\n{Y}{'═'*68}{N}")
    print(f"{BOLD}{C}   DAFTAR PERINTAH LINUX / TERMUX LENGKAP{N}")
    print(f"{Y}{'═'*68}{N}")
    print(f"\n{W}Ketik {C}man <perintah>{W} atau {C}help <perintah>{W} untuk info detail.{N}")
    print(f"{W}Ketik {C}contoh <perintah>{W} untuk melihat contoh-contoh penggunaan.{N}\n")

    category_names = {
        'navigasi':    ' NAVIGASI & EKSPLORASI',
        'file':        ' OPERASI FILE & DIREKTORI',
        'isi_file':    ' MELIHAT & MENULIS ISI FILE',
        'cari':        ' PENCARIAN',
        'permission':  ' PERMISSION & HAK AKSES',
        'proses':      ' MANAJEMEN PROSES',
        'jaringan':    ' JARINGAN',
        'arsip':       ' ARSIP & KOMPRESI',
        'disk':        ' MANAJEMEN DISK',
        'sistem':      ' INFO & KONFIGURASI SISTEM',
        'teks':        ' PENGOLAHAN TEKS',
        'paket':       ' MANAJEMEN PAKET',
        'lain':        ' UTILITAS LAINNYA',
    }

    for cat_key, cat_label in category_names.items():
        cmds = HELP_CATEGORIES.get(cat_key, [])
        print(f"  {G}{cat_label}{N}")
        # Tampilkan dalam baris, di 'if len(row) itu 6 per baris'.
        row = []
        for c in cmds:
            row.append(f"{C}{c:<12}{N}")
            if len(row) == 6:
                print("    " + "".join(row))
                row = []
        if row:
            print("    " + "".join(row))
        print()

    print(f"{Y}{'═'*68}{N}")
    print(f"{W}Total: {G}{len(COMMAND_INFO)}{W} perintah terdokumentasi.{N}")
    print(f"{W}Ketik {C}quiz{W} untuk uji pengetahuanmu! Ketik {C}cheatsheet{W} untuk ringkasan.{N}\n")

def show_examples(cmd_name):
    # ini deff untuk menampilkan contoh-contoh penggunaan perintah.
    info = COMMAND_INFO.get(cmd_name)
    if not info:
        print_error(f"Tidak ada contoh untuk '{cmd_name}'.")
        return
    print(f"\n{G} Contoh penggunaan '{cmd_name}':{N}")
    for i, (ex, desc) in enumerate(info.get('examples', []), 1):
        print(f"  {Y}{i}.{N} {C}$ {ex}{N}")
        print(f"     {DG}→ {desc}{N}")
    if info.get('tips'):
        print(f"\n{Y} {info['tips']}{N}")
    print()

def show_cheatsheet():
    # ini deff untuk menampilkan cheatsheet ringkas.
    print(f"\n{Y}╔{'═'*66}╗{N}")
    print(f"{Y}║{C}{BOLD}    CHEATSHEET LINUX / TERMUX - RINGKASAN CEPAT{' '*19}{Y}║{N}")
    print(f"{Y}╚{'═'*66}╝{N}")

    lines = [
        ('NAVIGASI',   [
            ('ls -la',            'Daftar file dengan detail'),
            ('cd folder',         'Masuk folder'),
            ('cd ..',             'Naik ke direktori induk'),
            ('pwd',               'Tampilkan lokasi saat ini'),
            ('tree -L 2',         'Struktur direktori 2 level'),
        ]),
        ('FILE & DIREKTORI', [
            ('touch file.txt',    'Buat file kosong'),
            ('mkdir -p a/b/c',    'Buat folder bersarang'),
            ('cp -r src/ dst/',   'Salin folder'),
            ('mv lama baru',      'Pindah/rename'),
            ('rm -rf folder/',    'Hapus folder paksa'),
        ]),
        ('MELIHAT FILE',   [
            ('cat file.txt',      'Tampilkan isi file'),
            ('head -n 20 file',   'Tampilkan 20 baris pertama'),
            ('tail -f log.txt',   'Pantau file log'),
            ('wc -l file.txt',    'Hitung baris'),
            ('grep pola file',    'Cari teks dalam file'),
        ]),
        ('TEKS & FILTER',  [
            ('cmd | grep kata',   'Filter output'),
            ('cmd | sort',        'Urutkan output'),
            ('cmd | uniq -c',     'Hitung unik'),
            ("sed 's/x/y/g' f",   'Ganti teks x→y'),
            ("awk '{print $1}' f",'Ambil kolom 1'),
        ]),
        ('SISTEM',   [
            ('ps aux | grep x',   'Cari proses'),
            ('kill -9 PID',       'Hentikan proses'),
            ('df -h',             'Cek ruang disk'),
            ('free -h',           'Cek penggunaan RAM'),
            ('uname -a',          'Info sistem'),
        ]),
        ('REDIRECT & PIPE', [
            ('cmd > file',        'Simpan output ke file (timpa)'),
            ('cmd >> file',       'Tambahkan output ke file'),
            ('cmd1 | cmd2',       'Pipe: output cmd1 → input cmd2'),
            ('cmd 2>&1',          'Redirect stderr ke stdout'),
            ('cmd1 && cmd2',      'Jalankan cmd2 jika cmd1 sukses'),
        ]),
    ]

    for title, items in lines:
        print(f"\n  {G}▶ {title}{N}")
        for cmd, desc in items:
            print(f"    {C}{cmd:<30}{N}{W}{desc}{N}")

    print(f"\n{Y}{'═'*68}{N}")
    print(f"{DG}  Ketik 'man <perintah>' untuk info lebih lengkap.{N}\n")

# ─── QUIZ ──────────────────────────────────────────────────────────────────────
QUIZ_QUESTIONS = [
    {"q": "Perintah apa yang digunakan untuk menampilkan daftar file di direktori saat ini?",
     "opts": ["ls", "dir", "list", "show"], "ans": 0,
     "explain": "'ls' (list) adalah perintah standar untuk melihat isi direktori di Linux."},
    {"q": "Bagaimana cara naik ke direktori induk (parent directory)?",
     "opts": ["cd up", "cd ..", "cd /", "go up"], "ans": 1,
     "explain": "'cd ..' menggunakan titik dua (..) yang berarti 'direktori induk' di Linux."},
    {"q": "Perintah apa untuk menampilkan direktori kerja saat ini?",
     "opts": ["cwd", "where", "pwd", "path"], "ans": 2,
     "explain": "'pwd' (Print Working Directory) menampilkan path lengkap direktori saat ini."},
    {"q": "Apa perbedaan '>' dan '>>' dalam redirect output?",
     "opts": ["Tidak ada bedanya", "'>' timpa file, '>>' tambahkan ke akhir",
              "'>>' timpa file, '>' tambahkan ke akhir", "Keduanya membuat file baru"], "ans": 1,
     "explain": "'>' menimpa (overwrite) isi file lama. '>>' menambahkan (append) ke akhir file tanpa menghapus isi sebelumnya."},
    {"q": "Perintah apa untuk mencari teks 'error' dalam file log.txt?",
     "opts": ["find 'error' log.txt", "search error log.txt",
              "grep 'error' log.txt", "locate error log.txt"], "ans": 2,
     "explain": "'grep' (Global Regular Expression Print) adalah perintah pencarian teks di Linux."},
    {"q": "Apa arti permission '755' pada file?",
     "opts": ["Pemilik: rwx, Group: r-x, Others: r-x",
              "Pemilik: rw-, Group: rw-, Others: r--",
              "Pemilik: rwx, Group: rwx, Others: r-x",
              "Semua bisa baca tulis"], "ans": 0,
     "explain": "7=rwx (4+2+1), 5=r-x (4+0+1). Jadi 755 = pemilik bisa baca/tulis/eksekusi, group & others hanya baca & eksekusi."},
    {"q": "Perintah apa yang dipakai untuk membuat direktori bersarang sekaligus (mkdir a/b/c)?",
     "opts": ["mkdir a/b/c", "mkdir -r a/b/c", "mkdir -p a/b/c", "mkdir --all a/b/c"], "ans": 2,
     "explain": "Opsi -p (parents) pada mkdir membuat semua direktori induk yang diperlukan sekaligus."},
    {"q": "Apa fungsi perintah 'chmod +x script.sh'?",
     "opts": ["Mengompres file", "Memberi izin eksekusi ke semua user",
              "Menghapus semua permission", "Mengubah pemilik file"], "ans": 1,
     "explain": "'+x' menambahkan izin eksekusi (execute). Tanpa ini, skrip tidak bisa dijalankan langsung."},
    {"q": "Perintah apa untuk melihat 10 baris TERAKHIR file log.txt?",
     "opts": ["head log.txt", "cat -10 log.txt", "tail log.txt", "end log.txt"], "ans": 2,
     "explain": "'tail' menampilkan baris TERAKHIR (ekor). 'head' menampilkan baris PERTAMA. Default: 10 baris."},
    {"q": "Apa fungsi simbol '|' (pipe) dalam perintah Linux?",
     "opts": ["Menggabungkan dua file", "Menyambungkan output perintah pertama ke input perintah kedua",
              "Menjalankan dua perintah secara bersamaan", "Redirect output ke file"], "ans": 1,
     "explain": "Pipe '|' menghubungkan output perintah kiri menjadi input perintah kanan. Contoh: ls | grep .txt"},
    {"q": "Perintah apa yang menampilkan penggunaan ruang disk?",
     "opts": ["disk -h", "space -h", "df -h", "storage -h"], "ans": 2,
     "explain": "'df' (Disk Free) menampilkan informasi penggunaan ruang disk semua partisi."},
    {"q": "Bagaimana cara menghapus direktori yang tidak kosong?",
     "opts": ["rm folder", "rmdir folder", "rm -r folder", "del folder"], "ans": 2,
     "explain": "'rm -r' (recursive) menghapus direktori beserta semua isinya. Hati-hati, tidak ada recycle bin!"},
]

def run_quiz():
    # Ini deff untuk menjalankan mode kuis interaktif.
    clear_screen()
    print(f"\n{Y}╔{'═'*60}╗")
    print(f"║{C}{BOLD}  KUIS PENGETAHUAN LINUX / TERMUX  {' '*25}{Y}║")
    print(f"╚{'═'*60}╝{N}\n")
    print(f"{W}Uji seberapa jauh kamu memahami perintah Linux!{N}")
    print(f"{W}Jawab dengan mengetik nomor pilihan (1-4).{N}\n")
    time.sleep(1)

    questions = random.sample(QUIZ_QUESTIONS, min(7, len(QUIZ_QUESTIONS)))
    score = 0
    wrong_list = []

    for i, q in enumerate(questions, 1):
        print(f"{G}{'─'*62}{N}")
        print(f"{C}Soal {i}/{len(questions)}:{N} {W}{q['q']}{N}\n")
        for j, opt in enumerate(q['opts'], 1):
            print(f"  {Y}{j}.{N} {opt}")
        print()

        while True:
            try:
                ans = input(f"{G}Jawaban kamu (1-4): {N}").strip()
                if ans in ('1','2','3','4'):
                    idx = int(ans) - 1
                    break
                else:
                    print_error("Masukkan angka 1, 2, 3, atau 4.")
            except (ValueError, KeyboardInterrupt):
                print()
                return

        if idx == q['ans']:
            print_ok(f"BENAR!")
            score += 1
        else:
            print_error(f"Salah. Jawaban yang tepat: {q['opts'][q['ans']]}")
            wrong_list.append(q)

        print(f"{DG}  ℹ {q['explain']}{N}\n")
        time.sleep(0.5)

    # Hasil akhir
    percent = (score / len(questions)) * 100
    print(f"\n{Y}╔{'═'*61}╗")
    print(f"║{C}{BOLD}  HASIL KUIS{' '*49}{Y}║")
    print(f"╚{'═'*61}╝{N}")
    print(f"\n  Skor kamu: {G}{score}{N}/{W}{len(questions)}{N} ({Y}{percent:.0f}%{N})\n")

    if percent == 100:
        print(f"  {G}SEMPURNA! Kamu luar biasa! Kuasai Linux dengan baik!{N}")
    elif percent >= 80:
        print(f"  {G}BAGUS SEKALI! Hampir sempurna. Teruskan belajar!{N}")
    elif percent >= 60:
        print(f"  {Y}LUMAYAN! Ada beberapa yang perlu dipelajari lagi.{N}")
    elif percent >= 40:
        print(f"  {Y}CUKUP! Perlu lebih banyak latihan ya.{N}")
    else:
        print(f"  {R}SEMANGAT! Jangan menyerah, terus belajar!{N}")

    if wrong_list:
        print(f"\n  {Y}Perintah yang perlu dipelajari lagi:{N}")
        for q in wrong_list:
            print(f"  {R}• {q['q'][:60]}...{N}" if len(q['q'])>60 else f"  {R}• {q['q']}{N}")
        print(f"\n  {DG}Gunakan 'man <perintah>' untuk belajar lebih dalam.{N}")
    print()

# ─── EKSEKUSI PERINTAH ─────────────────────────────────────────────────────────
def execute_command(raw_cmd):
    global current_path_list, alias_dict, env_vars, command_count

    # Expand alias
    _parts = raw_cmd.split()
    if _parts and _parts[0] in alias_dict:
        first = _parts[0]
        raw_cmd = alias_dict[first] + raw_cmd[len(first):]

    command_history.append(raw_cmd)
    command_count['total'] += 1

    parts = raw_cmd.split(maxsplit=3)
    if not parts:
        return True

    cmd  = parts[0]
    args = parts[1:]

    current_dir = get_dir(current_path_list)

    # ── ls ──────────────────────────────────────────────────────────────────────
    if cmd == 'ls':
        show_long   = '-l' in raw_cmd or '-la' in raw_cmd or '-al' in raw_cmd or '-lh' in raw_cmd
        show_hidden = '-a' in raw_cmd or '-la' in raw_cmd or '-al' in raw_cmd
        show_h      = '-h' in raw_cmd or '-lh' in raw_cmd

        # Tentukan direktori yang ingin ditampilkan
        target_args = [a for a in args if not a.startswith('-')]
        if target_args:
            target_path = resolve_path(current_path_list, target_args[0])
            target_dir  = get_dir(target_path)
            if target_dir is None:
                print_error(f"ls: Tidak dapat mengakses '{target_args[0]}': Tidak ada file atau direktori.")
                return True
        else:
            target_dir = current_dir

        items = sorted(target_dir.items(), key=lambda x: (isinstance(x[1], str), x[0]))
        visible = [(n, v) for n, v in items if show_hidden or not n.startswith('.')]

        if not visible:
            print(f"  {DG}(direktori kosong){N}")
            return True

        if show_long:
            print(f"{DG}total {len(visible)}{N}")
            for name, val in visible:
                is_dir = isinstance(val, dict)
                perm   = get_perm(path_str(current_path_list + [name]), is_dir)
                size   = format_size(file_size(val)) if not is_dir else '-'
                dt     = fake_date()
                color  = B if is_dir else W
                suffix = '/' if is_dir else ''
                size_c = f"{DG}{size:>5}{N}" if show_h else f"{DG}{'0' if is_dir else str(file_size(val)):>8}{N}"
                print(f"  {DG}{perm}{N}  1 user user {size_c} {DG}{dt}{N}  {color}{name}{suffix}{N}")
        else:
            row = []
            for name, val in visible:
                is_dir = isinstance(val, dict)
                color  = B if is_dir else W
                row.append(f"{color}{name}{'/' if is_dir else ''}{N}")
            print("  " + "  ".join(row))
        command_count['correct'] += 1

    # ── pwd ─────────────────────────────────────────────────────────────────────
    elif cmd == 'pwd':
        print(f"  {W}{path_str(current_path_list)}{N}")
        command_count['correct'] += 1

    # ── cd ──────────────────────────────────────────────────────────────────────
    elif cmd == 'cd':
        if not args:
            current_path_list = ['home', 'user']
            env_vars['PWD'] = path_str(current_path_list)
            print_info("Kembali ke home directory.")
            return True

        target = args[0]
        if target == '-':
            print_info("cd - (kembali ke direktori sebelumnya) — simulasi tidak menyimpan history.")
            return True
        if target == '~':
            current_path_list = ['home', 'user']
            env_vars['PWD'] = path_str(current_path_list)
            print_info("Kembali ke home directory.")
            return True

        new_path = resolve_path(current_path_list, target)
        node = get_dir(new_path)
        if node is not None:
            current_path_list = new_path
            env_vars['PWD'] = path_str(current_path_list)
            command_count['correct'] += 1
        else:
            # Cek apakah itu file bukan direktori
            node2 = get_node(new_path)
            if node2 is not None:
                print_error(f"cd: '{target}': Bukan direktori.")
            else:
                print_error(f"cd: '{target}': Tidak ada file atau direktori.")
            print_tip("Cek nama direktori dengan 'ls' dulu.")

    # ── mkdir ────────────────────────────────────────────────────────────────────
    elif cmd == 'mkdir':
        if not args:
            print_error("Penggunaan: mkdir [opsi] <nama_direktori>")
            print_tip("Contoh: mkdir folder_baru  atau  mkdir -p a/b/c")
            return True

        is_parents = '-p' in raw_cmd
        names = [a for a in args if not a.startswith('-')]

        for name in names:
            if is_parents and '/' in name:
                # Buat bertahap
                parts_p = name.strip('/').split('/')
                base    = list(current_path_list)
                for part in parts_p:
                    node = get_dir(base)
                    if part not in node:
                        node[part] = {}
                    base.append(part)
                print_ok(f"Direktori '{name}' (beserta induknya) berhasil dibuat.")
            else:
                if '/' in name:
                    print_error(f"mkdir: Tidak bisa membuat '{name}': Gunakan -p untuk path bersarang.")
                    continue
                if current_dir is None:
                    print_error("Error internal.")
                    continue
                if name in current_dir:
                    print_error(f"mkdir: Tidak bisa membuat direktori '{name}': Sudah ada.")
                else:
                    current_dir[name] = {}
                    print_ok(f"Direktori '{name}' berhasil dibuat.")
                    command_count['correct'] += 1

    # ── touch ────────────────────────────────────────────────────────────────────
    elif cmd == 'touch':
        if not args:
            print_error("Penggunaan: touch <nama_file>")
            print_tip("Contoh: touch file.txt  atau  touch a.txt b.txt c.txt")
            return True

        for name in args:
            if name.startswith('-'):
                continue
            if current_dir is None:
                print_error("Error internal."); continue
            if name in current_dir and isinstance(current_dir[name], dict):
                print_error(f"touch: Tidak bisa mengubah '{name}': Ini adalah direktori.")
            elif name in current_dir:
                print_info(f"Timestamp '{name}' diperbarui.")
            else:
                current_dir[name] = ""
                print_ok(f"File '{name}' berhasil dibuat.")
                command_count['correct'] += 1

    # ── cat ──────────────────────────────────────────────────────────────────────
    elif cmd == 'cat':
        # Mode: cat > file.txt  (menulis)
        if len(args) >= 2 and args[0] == '>':
            fname = args[1]
            print(f"{C}Ketik teks (Ctrl+D / baris kosong+Enter untuk selesai):{N}")
            lines = []
            while True:
                try:
                    line = input()
                    lines.append(line)
                except EOFError:
                    break
            if current_dir is not None:
                current_dir[fname] = '\n'.join(lines)
                print_ok(f"Teks berhasil ditulis ke '{fname}'.")
            return True

        # Mode: cat >> file.txt  (append)
        if len(args) >= 2 and args[0] == '>>':
            fname = args[1]
            print(f"{C}Ketik teks (baris kosong+Enter untuk selesai):{N}")
            lines = []
            while True:
                try:
                    line = input()
                    if line == '':
                        break
                    lines.append(line)
                except EOFError:
                    break
            if current_dir is not None and fname in current_dir and isinstance(current_dir[fname], str):
                current_dir[fname] += '\n' + '\n'.join(lines)
            elif current_dir is not None:
                current_dir[fname] = '\n'.join(lines)
            print_ok(f"Teks berhasil ditambahkan ke '{fname}'.")
            return True

        show_num = '-n' in raw_cmd
        fnames   = [a for a in args if not a.startswith('-')]

        if not fnames:
            print_error("Penggunaan: cat [opsi] <nama_file>")
            print_tip("Contoh: cat file.txt  atau  cat -n file.txt")
            return True

        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                content = current_dir[fname]
                if content == "":
                    print_info(f"'{fname}' adalah file kosong.")
                else:
                    for i, line in enumerate(content.split('\n'), 1):
                        if show_num:
                            print(f"  {DG}{i:4d}{N}  {W}{line}{N}")
                        else:
                            print(f"  {W}{line}{N}")
                command_count['correct'] += 1
            elif current_dir and fname in current_dir and isinstance(current_dir[fname], dict):
                print_error(f"cat: '{fname}': Ini adalah direktori.")
            else:
                print_error(f"cat: '{fname}': Tidak ada file atau direktori.")
                print_tip(f"Cek nama file dengan 'ls'. Pastikan kamu berada di direktori yang benar.")

    # ── head ─────────────────────────────────────────────────────────────────────
    elif cmd == 'head':
        n = 10
        fnames = []
        i = 0
        while i < len(args):
            if args[i] == '-n' and i+1 < len(args):
                try: n = int(args[i+1]); i += 2; continue
                except: pass
            elif args[i].startswith('-n'):
                try: n = int(args[i][2:]); i += 1; continue
                except: pass
            if not args[i].startswith('-'):
                fnames.append(args[i])
            i += 1

        if not fnames:
            print_error("Penggunaan: head [-n N] <file>")
            return True

        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                lines = current_dir[fname].split('\n')[:n]
                for line in lines:
                    print(f"  {W}{line}{N}")
                command_count['correct'] += 1
            else:
                print_error(f"head: '{fname}': Tidak ada file atau direktori.")

    # ── tail ─────────────────────────────────────────────────────────────────────
    elif cmd == 'tail':
        n       = 10
        follow  = '-f' in raw_cmd
        fnames  = []
        i = 0
        while i < len(args):
            if args[i] == '-n' and i+1 < len(args):
                try: n = int(args[i+1]); i += 2; continue
                except: pass
            elif args[i].startswith('-n'):
                try: n = int(args[i][2:]); i += 1; continue
                except: pass
            if not args[i].startswith('-'):
                fnames.append(args[i])
            i += 1

        if not fnames:
            print_error("Penggunaan: tail [-n N] [-f] <file>")
            return True

        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                lines = current_dir[fname].split('\n')[-n:]
                for line in lines:
                    print(f"  {W}{line}{N}")
                if follow:
                    print_info(f"[Memantau '{fname}' — Ctrl+C untuk berhenti (simulasi: 3 detik)...]")
                    time.sleep(3)
                    print_info("[Tidak ada pembaruan baru (simulasi).]")
                command_count['correct'] += 1
            else:
                print_error(f"tail: '{fname}': Tidak ada file atau direktori.")

    # ── echo ─────────────────────────────────────────────────────────────────────
    elif cmd == 'echo':
        # Tangani redirect
        full_args = ' '.join(args)

        if '>>' in full_args:
            idx = full_args.index('>>')
            text = full_args[:idx].strip().strip('"\'')
            fname = full_args[idx+2:].strip()
            text = expand_vars(text)
            if current_dir is not None:
                if fname in current_dir and isinstance(current_dir[fname], str):
                    current_dir[fname] += '\n' + text
                else:
                    current_dir[fname] = text
                print_ok(f"Teks berhasil ditambahkan ke '{fname}'.")
            command_count['correct'] += 1
        elif '>' in full_args:
            idx = full_args.index('>')
            text = full_args[:idx].strip().strip('"\'')
            fname = full_args[idx+1:].strip()
            text = expand_vars(text)
            if current_dir is not None:
                current_dir[fname] = text
                print_ok(f"Teks berhasil ditulis ke '{fname}'.")
            command_count['correct'] += 1
        else:
            text = full_args.strip().strip('"\'')
            text = expand_vars(text)
            if '-e' in raw_cmd:
                text = text.replace('\\n', '\n').replace('\\t', '\t')
            print(f"  {W}{text}{N}")
            command_count['correct'] += 1

    # ── wc ───────────────────────────────────────────────────────────────────────
    elif cmd == 'wc':
        only_lines = '-l' in raw_cmd
        only_words = '-w' in raw_cmd
        only_chars = '-c' in raw_cmd
        fnames = [a for a in args if not a.startswith('-')]

        if not fnames:
            print_error("Penggunaan: wc [-l|-w|-c] <file>")
            return True

        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                content = current_dir[fname]
                nl = len(content.split('\n'))
                nw = len(content.split())
                nc = len(content.encode())
                if only_lines:
                    print(f"  {W}{nl:6d}  {fname}{N}")
                elif only_words:
                    print(f"  {W}{nw:6d}  {fname}{N}")
                elif only_chars:
                    print(f"  {W}{nc:6d}  {fname}{N}")
                else:
                    print(f"  {W}{nl:6d} {nw:6d} {nc:6d}  {fname}{N}")
                command_count['correct'] += 1
            else:
                print_error(f"wc: '{fname}': Tidak ada file atau direktori.")

    # ── grep ─────────────────────────────────────────────────────────────────────
    elif cmd == 'grep':
        if len(args) < 1:
            print_error("Penggunaan: grep [opsi] <pola> [file]")
            print_tip("Contoh: grep 'error' log.txt  atau  grep -i 'hello' file.txt")
            return True

        no_case   = '-i' in raw_cmd
        show_num  = '-n' in raw_cmd
        invert    = '-v' in raw_cmd
        count_    = '-c' in raw_cmd
        recursive = '-r' in raw_cmd

        clean_args = [a for a in args if not a.startswith('-')]
        if len(clean_args) < 1:
            print_error("Harap tentukan pola pencarian.")
            return True

        pattern = clean_args[0].strip('"\'')
        fnames  = clean_args[1:]

        if not fnames:
            print_error("Harap tentukan file yang ingin dicari.")
            print_tip("Contoh: grep 'kata' file.txt  atau  grep -r 'kata' folder/")
            return True

        def search_in_content(fname, content, patt, no_c, show_n, inv, cnt):
            found = []
            for i, line in enumerate(content.split('\n'), 1):
                match_line = line.lower() if no_c else line
                match_patt = patt.lower() if no_c else patt
                matched = match_patt in match_line
                if inv:
                    matched = not matched
                if matched:
                    found.append((i, line))
            if cnt:
                print(f"  {C}{fname}:{N}{W}{len(found)}{N}")
            else:
                for lnum, line in found:
                    hi_line = line.replace(patt, f"{R}{patt}{W}") if not inv else line
                    if show_n:
                        print(f"  {C}{fname}:{DG}{lnum}:{N}{W}{hi_line}{N}")
                    else:
                        print(f"  {W}{hi_line}{N}")
            return len(found)

        total = 0
        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                total += search_in_content(fname, current_dir[fname], pattern, no_case, show_num, invert, count_)
            else:
                print_error(f"grep: '{fname}': Tidak ada file atau direktori.")

        if total == 0 and not count_:
            print_info(f"Tidak ditemukan '{pattern}'.")
        else:
            command_count['correct'] += 1

    # ── find ─────────────────────────────────────────────────────────────────────
    elif cmd == 'find':
        # find . -name "*.txt" -type f
        clean_args = [a for a in args if a not in ('-name', '-iname', '-type', '-size', '-empty')]
        name_pat   = None
        type_filt  = None
        only_empty = '-empty' in raw_cmd

        # Parse argumen find sederhana
        i = 0
        while i < len(args):
            if args[i] in ('-name', '-iname') and i+1 < len(args):
                name_pat = args[i+1].strip('"\'*')
                i += 2
            elif args[i] == '-type' and i+1 < len(args):
                type_filt = args[i+1]
                i += 2
            else:
                i += 1

        start = resolve_path(current_path_list, args[0]) if args and not args[0].startswith('-') else current_path_list
        results = []

        def find_recursive(node, path_l):
            if not isinstance(node, dict):
                return
            for name, val in node.items():
                p = path_l + [name]
                is_dir = isinstance(val, dict)
                match = True
                if name_pat and name_pat.lower() not in name.lower():
                    match = False
                if type_filt == 'f' and is_dir:
                    match = False
                if type_filt == 'd' and not is_dir:
                    match = False
                if only_empty:
                    if is_dir and val:
                        match = False
                    elif not is_dir and val:
                        match = False
                if match:
                    results.append(path_str(p))
                if is_dir:
                    find_recursive(val, p)

        start_node = get_dir(start)
        if start_node:
            find_recursive(start_node, start)

        if results:
            for r in results:
                print(f"  {C}{r}{N}")
            command_count['correct'] += 1
        else:
            print_info("Tidak ada hasil yang ditemukan.")

    # ── cp ───────────────────────────────────────────────────────────────────────
    elif cmd == 'cp':
        is_recursive = '-r' in raw_cmd or '-R' in raw_cmd
        fnames = [a for a in args if not a.startswith('-')]

        if len(fnames) < 2:
            print_error("Penggunaan: cp [opsi] <sumber> <tujuan>")
            print_tip("Contoh: cp file.txt salinan.txt  atau  cp -r folder/ backup/")
            return True

        src, dst = fnames[0], fnames[1]

        if current_dir and src in current_dir:
            if isinstance(current_dir[src], dict) and not is_recursive:
                print_error(f"cp: '{src}' adalah direktori; gunakan opsi -r.")
            else:
                import copy
                current_dir[dst] = copy.deepcopy(current_dir[src])
                kind = "Direktori" if isinstance(current_dir[src], dict) else "File"
                print_ok(f"{kind} '{src}' berhasil disalin ke '{dst}'.")
                command_count['correct'] += 1
        else:
            print_error(f"cp: '{src}': Tidak ada file atau direktori.")

    # ── mv ───────────────────────────────────────────────────────────────────────
    elif cmd == 'mv':
        fnames = [a for a in args if not a.startswith('-')]
        if len(fnames) < 2:
            print_error("Penggunaan: mv <sumber> <tujuan>")
            print_tip("Contoh: mv lama.txt baru.txt  atau  mv file.txt folder/")
            return True

        src, dst = fnames[0], fnames[1]

        if current_dir and src in current_dir:
            # Cek apakah tujuan adalah direktori yang ada
            dst_node = get_node(resolve_path(current_path_list, dst))
            if isinstance(dst_node, dict):
                # Pindahkan ke dalam direktori tujuan
                dst_node[src] = current_dir[src]
                del current_dir[src]
                print_ok(f"'{src}' berhasil dipindahkan ke '{dst}/'.")
            else:
                current_dir[dst] = current_dir[src]
                del current_dir[src]
                print_ok(f"'{src}' berhasil diubah nama/dipindahkan menjadi '{dst}'.")
            command_count['correct'] += 1
        else:
            print_error(f"mv: '{src}': Tidak ada file atau direktori.")

    # ── rm ───────────────────────────────────────────────────────────────────────
    elif cmd == 'rm':
        is_recursive = '-r' in raw_cmd or '-R' in raw_cmd
        is_force     = '-f' in raw_cmd
        fnames       = [a for a in args if not a.startswith('-')]

        if not fnames:
            print_error("Penggunaan: rm [opsi] <file/direktori>")
            print_tip("Contoh: rm file.txt  atau  rm -r folder/  atau  rm -rf folder/ (hati-hati!)")
            return True

        for fname in fnames:
            if fname == '/' or fname == '*':
                print_error(f"rm: DIBLOKIR — menghapus '{fname}' dilarang dalam simulator ini demi keamanan.")
                continue

            if current_dir and fname in current_dir:
                node = current_dir[fname]
                if isinstance(node, dict):
                    if not is_recursive:
                        print_error(f"rm: Tidak bisa menghapus '{fname}': Ini adalah direktori.")
                        print_tip("Gunakan 'rm -r folder' untuk menghapus direktori.")
                    elif node and not is_force:
                        ans = input(f"  {Y}rm: Yakin hapus '{fname}' beserta isinya? (y/N): {N}").strip().lower()
                        if ans == 'y':
                            del current_dir[fname]
                            print_ok(f"Direktori '{fname}' beserta isinya dihapus.")
                            command_count['correct'] += 1
                        else:
                            print_info("Dibatalkan.")
                    else:
                        del current_dir[fname]
                        print_ok(f"Direktori '{fname}' dihapus.")
                        command_count['correct'] += 1
                else:
                    del current_dir[fname]
                    print_ok(f"File '{fname}' dihapus.")
                    command_count['correct'] += 1
            elif not is_force:
                print_error(f"rm: Tidak bisa menghapus '{fname}': Tidak ada file atau direktori.")

    # ── chmod ────────────────────────────────────────────────────────────────────
    elif cmd == 'chmod':
        if len(args) < 2:
            print_error("Penggunaan: chmod <mode> <file>")
            print_tip("Contoh: chmod 755 script.sh  atau  chmod +x file.py")
            return True

        mode  = args[0]
        fnames = [a for a in args[1:] if not a.startswith('-')]

        for fname in fnames:
            pkey = path_str(current_path_list + [fname])
            is_d = fname in (current_dir or {}) and isinstance((current_dir or {}).get(fname), dict)
            old  = get_perm(pkey, is_d)

            # Numeric mode
            if mode.isdigit() and len(mode) == 3:
                chars = {'0':'---','1':'--x','2':'-w-','3':'-wx','4':'r--','5':'r-x','6':'rw-','7':'rwx'}
                new = ('d' if is_d else '-') + ''.join(chars.get(c,'---') for c in mode)
                set_perm(pkey, new)
                if fname in (current_dir or {}):
                    print_ok(f"Permission '{fname}' diubah menjadi {new} ({mode}).")
                    command_count['correct'] += 1
                else:
                    print_error(f"chmod: '{fname}': Tidak ada file atau direktori.")

            # Symbolic mode
            elif any(c in mode for c in '+-='):
                if fname in (current_dir or {}):
                    set_perm(pkey, f"{'d' if is_d else '-'}rwxr-xr-x" if '+x' in mode else old)
                    print_ok(f"Permission '{fname}' diperbarui ({mode}).")
                    command_count['correct'] += 1
                else:
                    print_error(f"chmod: '{fname}': Tidak ada file atau direktori.")
            else:
                print_error(f"chmod: Mode '{mode}' tidak valid.")

    # ── stat ─────────────────────────────────────────────────────────────────────
    elif cmd == 'stat':
        fnames = [a for a in args if not a.startswith('-')]
        if not fnames:
            print_error("Penggunaan: stat <file>")
            return True

        for fname in fnames:
            if current_dir and fname in current_dir:
                val  = current_dir[fname]
                is_d = isinstance(val, dict)
                pkey = path_str(current_path_list + [fname])
                perm = get_perm(pkey, is_d)
                size = file_size(val) if not is_d else 4096
                h    = hashlib.md5(fname.encode()).hexdigest()[:8]
                print(f"  {C}File: {W}'{fname}'{N}")
                print(f"  {C}Size: {W}{size:<12}{N}{C}Blocks: {W}8         {C}IO Block: {W}4096")
                print(f"  {C}Type: {W}{'directory' if is_d else 'regular file'}{N}")
                print(f"  {C}Inode: {W}{int(h,16) % 999999:<10}{N}{C}Links: {W}1{N}")
                print(f"  {C}Access: {W}({perm[1:4]}/{perm}){N}  Uid: {W}(1000/ user){N}  Gid: {W}(1000/ user){N}")
                print(f"  {C}Access: {W}{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{N}")
                print(f"  {C}Modify: {W}{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{N}")
                print(f"  {C}Change: {W}{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{N}")
                command_count['correct'] += 1
            else:
                print_error(f"stat: '{fname}': Tidak ada file atau direktori.")

    # ── tree ─────────────────────────────────────────────────────────────────────
    elif cmd == 'tree':
        max_depth = 999
        i = 0
        while i < len(args):
            if args[i] == '-L' and i+1 < len(args):
                try: max_depth = int(args[i+1]); i += 2; continue
                except: pass
            i += 1

        only_dirs = '-d' in raw_cmd

        start = list(current_path_list)
        if args and not args[0].startswith('-') and args[0] not in ('-L',):
            start = resolve_path(current_path_list, args[0])

        start_node = get_dir(start)
        if not start_node:
            print_error(f"tree: Direktori tidak ditemukan.")
            return True

        print(f"  {B}.{N}")
        dir_count = [0]; file_count = [0]

        def print_tree(node, prefix, depth):
            if depth > max_depth:
                return
            items = sorted(node.items(), key=lambda x: (isinstance(x[1], str), x[0]))
            for i, (name, val) in enumerate(items):
                is_last = (i == len(items) - 1)
                connector = '└── ' if is_last else '├── '
                is_dir = isinstance(val, dict)
                if only_dirs and not is_dir:
                    continue
                color = B if is_dir else W
                print(f"  {DG}{prefix}{connector}{color}{name}{'/' if is_dir else ''}{N}")
                if is_dir:
                    dir_count[0] += 1
                    ext = '    ' if is_last else '│   '
                    print_tree(val, prefix + ext, depth + 1)
                else:
                    file_count[0] += 1

        print_tree(start_node, '', 1)
        print(f"\n  {DG}{dir_count[0]} direktori, {file_count[0]} file{N}")
        command_count['correct'] += 1

    # ── sort ─────────────────────────────────────────────────────────────────────
    elif cmd == 'sort':
        reverse  = '-r' in raw_cmd
        numeric  = '-n' in raw_cmd
        unique   = '-u' in raw_cmd
        fnames   = [a for a in args if not a.startswith('-')]

        if not fnames:
            print_error("Penggunaan: sort [opsi] <file>")
            return True

        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                lines = current_dir[fname].split('\n')
                key_fn = (lambda x: int(x) if x.isdigit() else 0) if numeric else str
                lines.sort(key=key_fn, reverse=reverse)
                if unique:
                    seen = set(); lines = [l for l in lines if not (l in seen or seen.add(l))]
                for line in lines:
                    print(f"  {W}{line}{N}")
                command_count['correct'] += 1
            else:
                print_error(f"sort: '{fname}': Tidak ada file atau direktori.")

    # ── uniq ─────────────────────────────────────────────────────────────────────
    elif cmd == 'uniq':
        count_  = '-c' in raw_cmd
        dups    = '-d' in raw_cmd
        unique  = '-u' in raw_cmd
        fnames  = [a for a in args if not a.startswith('-')]

        if not fnames:
            print_error("Penggunaan: uniq [opsi] <file>")
            return True

        fname = fnames[0]
        if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
            from itertools import groupby
            lines = current_dir[fname].split('\n')
            for key, group in groupby(lines):
                grp = list(group)
                cnt = len(grp)
                if dups and cnt < 2:
                    continue
                if unique and cnt > 1:
                    continue
                if count_:
                    print(f"  {Y}{cnt:4d}{N}  {W}{key}{N}")
                else:
                    print(f"  {W}{key}{N}")
            command_count['correct'] += 1
        else:
            print_error(f"uniq: '{fname}': Tidak ada file atau direktori.")

    # ── diff ─────────────────────────────────────────────────────────────────────
    elif cmd == 'diff':
        fnames = [a for a in args if not a.startswith('-')]
        if len(fnames) < 2:
            print_error("Penggunaan: diff <file1> <file2>")
            return True

        f1, f2 = fnames[0], fnames[1]
        c1 = current_dir.get(f1) if current_dir else None
        c2 = current_dir.get(f2) if current_dir else None

        if not isinstance(c1, str):
            print_error(f"diff: '{f1}': File tidak ditemukan."); return True
        if not isinstance(c2, str):
            print_error(f"diff: '{f2}': File tidak ditemukan."); return True

        lines1 = c1.split('\n')
        lines2 = c2.split('\n')
        is_unified = '-u' in raw_cmd

        if lines1 == lines2:
            print_info("Kedua file identik (tidak ada perbedaan).")
        else:
            only_in_1 = set(lines1) - set(lines2)
            only_in_2 = set(lines2) - set(lines1)
            if is_unified:
                print(f"  {R}--- {f1}{N}")
                print(f"  {G}+++ {f2}{N}")
            for line in lines1:
                if line in only_in_1:
                    print(f"  {R}< {line}{N}")
            for line in lines2:
                if line in only_in_2:
                    print(f"  {G}> {line}{N}")
            command_count['correct'] += 1

    # ── df ───────────────────────────────────────────────────────────────────────
    elif cmd == 'df':
        human = '-h' in raw_cmd
        print(f"  {C}{'Filesystem':<20}{'Size':>8}{'Used':>8}{'Avail':>8}{'Use%':>6}  Mounted on{N}")
        rows = [
            ('/dev/sda1', '50G', '12G', '36G', '25%', '/'),
            ('/dev/sda2', '100G', '45G', '50G', '47%', '/home'),
            ('tmpfs', '2G', '1M', '2G', '1%', '/tmp'),
        ]
        for fs, size, used, avail, pct, mnt in rows:
            print(f"  {W}{fs:<20}{DG}{size:>8}{used:>8}{avail:>8}{Y}{pct:>6}{N}  {W}{mnt}{N}")
        print_tip("Perhatikan 'Use%'. Jika mendekati 100%, segera bersihkan ruang disk!")
        command_count['correct'] += 1

    # ── du ───────────────────────────────────────────────────────────────────────
    elif cmd == 'du':
        human   = '-h' in raw_cmd
        summary = '-s' in raw_cmd
        fnames  = [a for a in args if not a.startswith('-')]
        target  = fnames[0] if fnames else '.'

        target_path = resolve_path(current_path_list, target)
        target_node = get_dir(target_path)

        if target_node is None:
            print_error(f"du: '{target}': Tidak ada direktori.")
            return True

        def calc_size(node):
            total = 0
            for _, v in node.items():
                if isinstance(v, dict):
                    total += calc_size(v)
                else:
                    total += file_size(v)
            return total + 4096

        def print_du(node, p, depth=0):
            if depth > 0 and not summary:
                sz = calc_size(node)
                fmt = format_size(sz) if human else str(sz)
                print(f"  {W}{fmt:<8}{DG}{p}{N}")
            for name, val in node.items():
                if isinstance(val, dict):
                    print_du(val, p + '/' + name, depth+1)

        total_sz = calc_size(target_node)
        fmt = format_size(total_sz) if human else str(total_sz)

        if summary:
            print(f"  {W}{fmt:<8}{DG}{target}{N}")
        else:
            print_du(target_node, target)
            print(f"  {Y}{fmt:<8}{DG}total{N}")
        command_count['correct'] += 1

    # ── ps ───────────────────────────────────────────────────────────────────────
    elif cmd == 'ps':
        print(f"  {C}{'PID':>6}  {'TTY':<8} {'TIME':<10} {'CMD':<20}{N}")
        fake_procs = [
            (1,    'init',    '00:00:01'),
            (123,  'bash',    '00:00:00'),
            (456,  'python3', '00:00:03'),
            (789,  'sshd',    '00:00:00'),
            (1024, 'top',     '00:01:22'),
        ]
        if 'aux' in raw_cmd or '-ef' in raw_cmd:
            print(f"  {C}{'USER':<8}{'PID':>6}{'%CPU':>6}{'%MEM':>6}  {'VSZ':>8}  {'RSS':>8}  {'STAT':<5}  {'COMMAND':<20}{N}")
            for pid, name, t in fake_procs:
                cpu = random.uniform(0, 5)
                mem = random.uniform(0, 3)
                vsz = random.randint(10000, 50000)
                rss = random.randint(1000, 5000)
                print(f"  {W}user  {pid:>6}  {cpu:5.1f}  {mem:5.1f}  {vsz:>8}  {rss:>8}  Ss     {name:<20}{N}")
        else:
            for pid, name, t in fake_procs[:2]:
                print(f"  {W}{pid:>6}  pts/0    {t}    {name:<20}{N}")
        command_count['correct'] += 1

    # ── top ──────────────────────────────────────────────────────────────────────
    elif cmd == 'top':
        print(f"\n{G}[SIMULASI TOP - tekan Ctrl+C di sistem nyata untuk keluar]{N}")
        print(f"{DG}{'─'*60}{N}")
        print(f"  {C}top - {datetime.now().strftime('%H:%M:%S')}{N} up 2 days,  3:21,  1 user,  load average: 0.5, 0.3, 0.2")
        print(f"  {C}Tasks:{N} 120 total,   1 running, 119 sleeping")
        print(f"  {C}%Cpu(s):{N}  2.5 us,  1.2 sy,  0.0 ni, 96.1 id,  0.2 wa")
        print(f"  {C}MiB Mem:{N}  7950.0 total,  4821.3 free,  1872.4 used,  1256.3 buff/cache")
        print(f"  {C}MiB Swap:{N} 2048.0 total,  2048.0 free,     0.0 used.  5821.9 avail Mem")
        print(f"\n  {C}{'PID':<8}{'USER':<10}{'PR':<5}{'NI':<5}{'VIRT':>8}{'RES':>8}{'SHR':>8}  {'S':<3}{'%CPU':>6}{'%MEM':>6}{'TIME+':<12}{'COMMAND':<15}{N}")
        fake = [
            (1,'root',20,0,8396,6104,4396,'S',0.0,0.1,'0:01.23','systemd'),
            (456,'user',20,0,14356,3280,2844,'S',2.3,0.4,'0:03.45','python3'),
            (789,'user',20,0,12000,1200,900,'S',0.0,0.1,'0:00.12','sshd'),
        ]
        for pid,usr,pr,ni,virt,res,shr,s,cpu,mem,t,cmd_ in fake:
            print(f"  {W}{pid:<8}{usr:<10}{pr:<5}{ni:<5}{virt:>8}{res:>8}{shr:>8}  {s:<3}{cpu:>6.1f}{mem:>6.1f}{t:<12}{cmd_:<15}{N}")
        command_count['correct'] += 1

    # ── kill ─────────────────────────────────────────────────────────────────────
    elif cmd in ('kill', 'killall'):
        if not args:
            print_error(f"Penggunaan: {cmd} [-9] <PID/nama>")
            return True
        target = args[-1]
        sig    = '-9' if '-9' in raw_cmd else '-15 (SIGTERM)'
        print_ok(f"Sinyal {sig} dikirimkan ke '{target}' (simulasi).")
        print_tip("Di sistem nyata, dapatkan PID dulu dengan: ps aux | grep nama_program")
        command_count['correct'] += 1

    # ── uname ────────────────────────────────────────────────────────────────────
    elif cmd == 'uname':
        if '-a' in raw_cmd:
            print(f"  {W}Linux learning-simulator 5.15.0-91-generic #101-Ubuntu SMP x86_64 x86_64 x86_64 GNU/Linux{N}")
        elif '-r' in raw_cmd:
            print(f"  {W}5.15.0-91-generic{N}")
        elif '-m' in raw_cmd:
            print(f"  {W}x86_64{N}")
        elif '-n' in raw_cmd:
            print(f"  {W}learning-simulator{N}")
        else:
            print(f"  {W}Linux{N}")
        command_count['correct'] += 1

    # ── whoami ───────────────────────────────────────────────────────────────────
    elif cmd == 'whoami':
        print(f"  {W}user{N}")
        command_count['correct'] += 1

    # ── hostname ─────────────────────────────────────────────────────────────────
    elif cmd == 'hostname':
        if '-I' in raw_cmd:
            print(f"  {W}192.168.1.100 10.0.0.5{N}")
        else:
            print(f"  {W}learning-simulator{N}")
        command_count['correct'] += 1

    # ── date ─────────────────────────────────────────────────────────────────────
    elif cmd == 'date':
        if args and args[0].startswith('+'):
            fmt = args[0][1:].strip('"')
            fmt = fmt.replace('%Y', datetime.now().strftime('%Y'))
            fmt = fmt.replace('%m', datetime.now().strftime('%m'))
            fmt = fmt.replace('%d', datetime.now().strftime('%d'))
            fmt = fmt.replace('%H', datetime.now().strftime('%H'))
            fmt = fmt.replace('%M', datetime.now().strftime('%M'))
            fmt = fmt.replace('%S', datetime.now().strftime('%S'))
            fmt = fmt.replace('%B', datetime.now().strftime('%B'))
            print(f"  {W}{fmt}{N}")
        else:
            print(f"  {W}{datetime.now().strftime('%a %b %d %H:%M:%S %Z %Y')}{N}")
        command_count['correct'] += 1

    # ── uptime ───────────────────────────────────────────────────────────────────
    elif cmd == 'uptime':
        print(f"  {W}{datetime.now().strftime('%H:%M:%S')} up 2 days,  3:21,  1 user,  load average: 0.52, 0.31, 0.25{N}")
        command_count['correct'] += 1

    # ── free ─────────────────────────────────────────────────────────────────────
    elif cmd == 'free':
        human = '-h' in raw_cmd
        print(f"  {C}{'':>15}{'total':>10}{'used':>10}{'free':>10}{'shared':>10}{'buff/cache':>12}{'available':>12}{N}")
        if human:
            print(f"  {W}{'Mem:':>15}{'7.8Gi':>10}{'1.8Gi':>10}{'4.7Gi':>10}{'100Mi':>10}{'1.2Gi':>12}{'5.7Gi':>12}{N}")
            print(f"  {W}{'Swap:':>15}{'2.0Gi':>10}{'0B':>10}{'2.0Gi':>10}{N}")
        else:
            print(f"  {W}{'Mem:':>15}{'8140456':>10}{'1893824':>10}{'4847832':>10}{'105340':>10}{'1398800':>12}{'5872592':>12}{N}")
            print(f"  {W}{'Swap:':>15}{'2097148':>10}{'0':>10}{'2097148':>10}{N}")
        command_count['correct'] += 1

    # ── env ──────────────────────────────────────────────────────────────────────
    elif cmd == 'env':
        for k, v in env_vars.items():
            print(f"  {C}{k}{N}={W}{v}{N}")
        command_count['correct'] += 1

    # ── export ───────────────────────────────────────────────────────────────────
    elif cmd == 'export':
        if not args:
            for k, v in env_vars.items():
                print(f"  {C}export {k}{N}={W}{v}{N}")
            return True
        for arg in args:
            if '=' in arg:
                k, v = arg.split('=', 1)
                v = v.strip('"\'')
                env_vars[k] = v
                print_ok(f"Variabel '{k}' ditetapkan menjadi '{v}'.")
                command_count['correct'] += 1
            else:
                print_info(f"Variabel '{arg}' dimarkir untuk ekspor.")

    # ── alias ────────────────────────────────────────────────────────────────────
    elif cmd == 'alias':
        if not args:
            for k, v in alias_dict.items():
                print(f"  {C}alias {k}{N}='{W}{v}{N}'")
            return True
        for arg in args:
            if '=' in arg:
                k, v = arg.split('=', 1)
                v = v.strip("'\"")
                alias_dict[k] = v
                print_ok(f"Alias '{k}' dibuat: '{v}'.")
                command_count['correct'] += 1
            else:
                if arg in alias_dict:
                    print(f"  {C}alias {arg}{N}='{W}{alias_dict[arg]}{N}'")
                else:
                    print_error(f"alias: '{arg}' tidak ditemukan.")

    # ── unalias ──────────────────────────────────────────────────────────────────
    elif cmd == 'unalias':
        if args and args[0] in alias_dict:
            del alias_dict[args[0]]
            print_ok(f"Alias '{args[0]}' dihapus.")
        else:
            print_error(f"unalias: '{args[0] if args else ''}' tidak ditemukan.")

    # ── history ──────────────────────────────────────────────────────────────────
    elif cmd == 'history':
        n = int(args[0]) if args and args[0].isdigit() else len(command_history)
        shown = command_history[-n:]
        for i, h in enumerate(shown, len(command_history)-len(shown)+1):
            print(f"  {DG}{i:4d}{N}  {W}{h}{N}")
        command_count['correct'] += 1

    # ── cal ──────────────────────────────────────────────────────────────────────
    elif cmd == 'cal':
        import calendar
        now = datetime.now()
        year  = int(args[1]) if len(args) >= 2 else now.year
        month = int(args[0]) if len(args) >= 1 and args[0].isdigit() else now.month

        cal_str = calendar.month(year, month)
        for line in cal_str.split('\n'):
            day_str = str(now.day)
            if f' {now.day} ' in line and year == now.year and month == now.month:
                line = line.replace(f' {now.day} ', f' {Y}{now.day}{N} ', 1)
            print(f"  {C}{line}{N}")
        command_count['correct'] += 1

    # ── bc ───────────────────────────────────────────────────────────────────────
    elif cmd == 'bc':
        print_info("bc tidak tersedia secara langsung dalam simulator.")
        print_tip("Gunakan Python sebagai kalkulator: python3 -c 'print(5+3*2)'")

    # ── sleep ────────────────────────────────────────────────────────────────────
    elif cmd == 'sleep':
        if not args:
            print_error("Penggunaan: sleep <detik>")
            return True
        try:
            n = float(args[0].rstrip('smhd'))
            unit = args[0][-1] if args[0][-1] in 'smhd' else 's'
            mult = {'s':1,'m':60,'h':3600,'d':86400}.get(unit,1)
            secs = n * mult
            disp = min(secs, 3)
            print_info(f"Tidur selama {args[0]}... (simulasi dipercepat)")
            time.sleep(min(disp, 2))
            print_ok("Selesai.")
            command_count['correct'] += 1
        except ValueError:
            print_error(f"sleep: Nilai tidak valid: '{args[0]}'")

    # ── ping ─────────────────────────────────────────────────────────────────────
    elif cmd == 'ping':
        host = args[-1] if args else 'localhost'
        count = 4
        for a in args:
            if a.isdigit():
                count = int(a)
        print_info(f"PING {host} (simulasi jaringan):")
        for i in range(1, min(count, 4)+1):
            ms = random.uniform(10, 50)
            print(f"  {W}64 bytes from {host}: icmp_seq={i} ttl=64 time={ms:.2f} ms{N}")
            time.sleep(0.3)
        print(f"  {DG}--- {host} ping statistics ---{N}")
        print(f"  {W}{count} packets transmitted, {count} received, 0% packet loss{N}")
        command_count['correct'] += 1

    # ── curl / wget ──────────────────────────────────────────────────────────────
    elif cmd in ('curl', 'wget'):
        url = next((a for a in args if a.startswith('http')), None)
        if not url:
            print_error(f"{cmd}: URL tidak ditemukan.")
            return True
        print_info(f"[Simulasi] {cmd} sedang mengambil '{url}'...")
        time.sleep(1)
        print_ok(f"Berhasil (simulasi). Data dari '{url}' diterima.")
        print_tip(f"Di sistem nyata, {cmd} memerlukan koneksi internet aktif.")
        command_count['correct'] += 1

    # ── ssh ──────────────────────────────────────────────────────────────────────
    elif cmd == 'ssh':
        target = next((a for a in args if '@' in a or (not a.startswith('-') and '.' in a)), 'server')
        print_info(f"[Simulasi] Menghubungkan ke '{target}'...")
        time.sleep(1)
        print_ok(f"Koneksi ke '{target}' berhasil (simulasi).")
        print_info("Simulator tidak mendukung shell SSH interaktif.")
        print_tip("Di Termux nyata: pkg install openssh  kemudian  ssh user@ip")

    # ── tar ──────────────────────────────────────────────────────────────────────
    elif cmd == 'tar':
        is_create  = '-c' in raw_cmd
        is_extract = '-x' in raw_cmd
        is_list    = '-t' in raw_cmd
        is_verbose = '-v' in raw_cmd

        fnames = [a for a in args if not a.startswith('-')]
        archive = fnames[0] if fnames else 'arsip.tar'

        if is_create:
            targets = fnames[1:] if len(fnames) > 1 else ['(current dir)']
            print_ok(f"Membuat arsip '{archive}' dari: {', '.join(targets)} (simulasi).")
            if is_verbose:
                for t in targets:
                    print(f"  {DG}  menambahkan {t}{N}")
        elif is_extract:
            print_ok(f"Mengekstrak '{archive}' (simulasi).")
            if is_verbose:
                print(f"  {DG}  mengekstrak file1.txt, file2.txt, ...{N}")
        elif is_list:
            print_info(f"Isi arsip '{archive}' (simulasi):")
            print(f"  {DG}  file1.txt{N}")
            print(f"  {DG}  folder/{N}")
            print(f"  {DG}  folder/file2.py{N}")
        else:
            print_error("tar: Tentukan operasi: -c (buat), -x (ekstrak), atau -t (lihat isi)")
            print_tip("Contoh: tar -czvf arsip.tar.gz folder/  atau  tar -xzvf arsip.tar.gz")
        command_count['correct'] += 1

    # ── zip / unzip ───────────────────────────────────────────────────────────────
    elif cmd == 'zip':
        fnames = [a for a in args if not a.startswith('-')]
        archive = fnames[0] if fnames else 'arsip.zip'
        targets = fnames[1:] if len(fnames) > 1 else ['(current dir)']
        print_ok(f"Membuat '{archive}' dari: {', '.join(targets)} (simulasi).")
        command_count['correct'] += 1

    elif cmd == 'unzip':
        fnames = [a for a in args if not a.startswith('-')]
        archive = fnames[0] if fnames else 'arsip.zip'
        dest_args = [args[i+1] for i, a in enumerate(args) if a == '-d' and i+1 < len(args)]
        dest = dest_args[0] if dest_args else '.'
        if '-l' in raw_cmd:
            print_info(f"Isi '{archive}' (simulasi):")
            for f in ['file1.txt','folder/file2.py','readme.md']:
                print(f"  {DG}  {f}{N}")
        else:
            print_ok(f"Mengekstrak '{archive}' ke '{dest}' (simulasi).")
        command_count['correct'] += 1

    # ── gzip ─────────────────────────────────────────────────────────────────────
    elif cmd in ('gzip', 'gunzip'):
        fnames = [a for a in args if not a.startswith('-')]
        if not fnames:
            print_error(f"Penggunaan: {cmd} <file>"); return True
        if cmd == 'gzip':
            print_ok(f"'{fnames[0]}' → '{fnames[0]}.gz' (simulasi).")
        else:
            name = fnames[0].replace('.gz', '')
            print_ok(f"'{fnames[0]}' → '{name}' (simulasi).")
        command_count['correct'] += 1

    # ── sudo ─────────────────────────────────────────────────────────────────────
    elif cmd == 'sudo':
        if not args:
            print_error("Penggunaan: sudo <perintah>")
            return True
        sub_cmd = ' '.join(args)
        print_info(f"[sudo] Menjalankan '{sub_cmd}' sebagai root (simulasi)...")
        time.sleep(0.5)
        # Jalankan sub-perintah
        return execute_command(sub_cmd)

    # ── su ───────────────────────────────────────────────────────────────────────
    elif cmd == 'su':
        user = args[0].lstrip('-') if args else 'root'
        print_info(f"Berganti ke user '{user}' (simulasi). Ketik 'exit' untuk kembali.")

    # ── apt / pkg ─────────────────────────────────────────────────────────────────
    elif cmd in ('apt', 'pkg', 'apt-get'):
        if not args:
            print_error(f"Penggunaan: {cmd} <subperintah> [paket]")
            return True
        sub = args[0]
        pkgs = args[1:] if len(args) > 1 else []

        if sub == 'update':
            print_info("Memperbarui daftar paket... (simulasi)")
            for i in range(3):
                time.sleep(0.3)
                print(f"  {DG}Get:{i+1} http://repo.ubuntu.com/ubuntu focal InRelease{N}")
            print_ok("Daftar paket berhasil diperbarui (simulasi).")
        elif sub == 'upgrade':
            print_info("Memperbarui semua paket... (simulasi)")
            print_ok("Semua paket sudah versi terbaru (simulasi).")
        elif sub in ('install',):
            for pkg in pkgs:
                print_info(f"Menginstal '{pkg}'...")
                time.sleep(0.5)
                print_ok(f"'{pkg}' berhasil diinstal (simulasi).")
        elif sub in ('remove', 'purge'):
            for pkg in pkgs:
                print_info(f"Menghapus '{pkg}'...")
                time.sleep(0.3)
                print_ok(f"'{pkg}' berhasil dihapus (simulasi).")
        elif sub == 'search':
            kw = pkgs[0] if pkgs else ''
            print_info(f"Mencari paket '{kw}' (simulasi):")
            fake_pkgs = [f"{kw}-dev", f"lib{kw}", f"python3-{kw}", f"{kw}-utils"]
            for p in fake_pkgs:
                print(f"  {C}{p}{N} - {DG}Paket {p} versi 1.0 (simulasi){N}")
        elif sub in ('show', 'info'):
            pkg = pkgs[0] if pkgs else 'unknown'
            print(f"  {C}Package: {W}{pkg}{N}")
            print(f"  {C}Version: {W}1.0.0-1{N}")
            print(f"  {C}Description: {W}Paket simulasi {pkg}{N}")
        elif sub in ('list',):
            print_info("Paket terinstal (simulasi):")
            for p in ['bash','python3','git','nano','curl','wget','vim','htop']:
                print(f"  {C}{p}{N}/{DG}focal,now 1.0.0 amd64 [installed]{N}")
        else:
            print_error(f"{cmd}: Subperintah '{sub}' tidak dikenal.")
        command_count['correct'] += 1

    # ── pip ──────────────────────────────────────────────────────────────────────
    elif cmd == 'pip' or cmd == 'pip3':
        if not args:
            print_error("Penggunaan: pip <subperintah> [paket]")
            return True
        sub  = args[0]
        pkgs = args[1:] if len(args) > 1 else []

        if sub == 'install':
            for pkg in pkgs:
                if pkg.startswith('-r'):
                    req = pkgs[pkgs.index(pkg)+1] if pkgs.index(pkg)+1 < len(pkgs) else 'requirements.txt'
                    print_ok(f"Menginstal dari '{req}' (simulasi).")
                else:
                    print_info(f"Mengumpulkan {pkg}...")
                    time.sleep(0.3)
                    print_ok(f"Successfully installed {pkg}-latest (simulasi).")
        elif sub == 'list':
            pkgs_list = [('requests','2.31.0'),('numpy','1.26.0'),('pandas','2.1.0'),
                         ('flask','3.0.0'),('pillow','10.0.0'),('matplotlib','3.8.0')]
            print(f"  {C}{'Package':<25}{'Version':<15}{N}")
            print(f"  {DG}{'─'*40}{N}")
            for p,v in pkgs_list:
                print(f"  {W}{p:<25}{v:<15}{N}")
        elif sub in ('show', 'info'):
            pkg = pkgs[0] if pkgs else 'unknown'
            print(f"  {C}Name: {W}{pkg}\n  {C}Version: {W}1.0.0\n  {C}Summary: {W}Library {pkg} (simulasi){N}")
        elif sub == 'uninstall':
            for pkg in pkgs:
                print_ok(f"'{pkg}' berhasil dihapus (simulasi).")
        elif sub == 'freeze':
            reqs = ['requests==2.31.0','numpy==1.26.0','pandas==2.1.0']
            for r in reqs:
                print(f"  {W}{r}{N}")
        else:
            print_error(f"pip: Subperintah '{sub}' tidak dikenal.")
        command_count['correct'] += 1

    # ── id / groups ───────────────────────────────────────────────────────────────
    elif cmd == 'id':
        print(f"  {W}uid=1000(user) gid=1000(user) groups=1000(user),4(adm),24(cdrom),27(sudo),30(dip),46(plugdev){N}")
        command_count['correct'] += 1

    elif cmd == 'groups':
        print(f"  {W}user adm cdrom sudo dip plugdev lpadmin sambashare{N}")
        command_count['correct'] += 1

    # ── which / locate ────────────────────────────────────────────────────────────
    elif cmd == 'which':
        paths = {'ls':'/bin/ls','cat':'/bin/cat','python3':'/usr/bin/python3',
                 'bash':'/bin/bash','grep':'/bin/grep','find':'/usr/bin/find',
                 'git':'/usr/bin/git','nano':'/usr/bin/nano','curl':'/usr/bin/curl'}
        for a in args:
            if a in paths:
                print(f"  {W}{paths[a]}{N}")
            else:
                print_info(f"which: '{a}' tidak ditemukan di PATH (simulasi).")
        command_count['correct'] += 1

    elif cmd == 'locate':
        if not args:
            print_error("Penggunaan: locate <pola>")
            return True
        pat = args[0].strip('"\'')
        results = []

        def loc_search(node, path_l):
            for name, val in node.items():
                if pat.lower() in name.lower():
                    results.append(path_str(path_l + [name]))
                if isinstance(val, dict):
                    loc_search(val, path_l + [name])

        loc_search(simulated_filesystem, [])
        if results:
            for r in results:
                print(f"  {C}{r}{N}")
        else:
            print_info(f"Tidak ada hasil untuk '{pat}'.")
        command_count['correct'] += 1

    # ── sed ───────────────────────────────────────────────────────────────────────
    elif cmd == 'sed':
        # sed 's/old/new/g' file
        if not args:
            print_error("Penggunaan: sed 's/lama/baru/g' <file>")
            return True

        in_place = '-i' in raw_cmd
        cmd_args  = [a for a in args if not a.startswith('-')]
        if not cmd_args:
            print_error("Harap berikan ekspresi sed.")
            return True

        expr = cmd_args[0].strip("'\"")
        fnames = cmd_args[1:]

        if expr.startswith('s/'):
            parts_s = expr[2:].split('/')
            if len(parts_s) >= 2:
                old, new = parts_s[0], parts_s[1]
                flag     = parts_s[2] if len(parts_s) > 2 else ''
                for fname in fnames:
                    if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                        orig = current_dir[fname]
                        if 'g' in flag:
                            result = orig.replace(old, new)
                        else:
                            result = orig.replace(old, new, 1)
                        if in_place:
                            current_dir[fname] = result
                            print_ok(f"'{fname}' diubah (in-place).")
                        else:
                            for line in result.split('\n'):
                                print(f"  {W}{line}{N}")
                        command_count['correct'] += 1
                    else:
                        print_error(f"sed: '{fname}': Tidak ada file atau direktori.")
        elif expr.startswith('/') and expr.endswith('d'):
            # Hapus baris
            for fname in fnames:
                if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                    pat = expr[1:expr.rfind('/')]
                    lines = [l for l in current_dir[fname].split('\n') if pat not in l]
                    if in_place:
                        current_dir[fname] = '\n'.join(lines)
                        print_ok(f"Baris yang cocok dengan '{pat}' dihapus dari '{fname}'.")
                    else:
                        for line in lines:
                            print(f"  {W}{line}{N}")
                    command_count['correct'] += 1
        else:
            print_error(f"sed: Ekspresi '{expr}' belum didukung simulator ini.")
            print_tip("Contoh yang didukung: sed 's/lama/baru/g' file.txt")

    # ── awk ───────────────────────────────────────────────────────────────────────
    elif cmd == 'awk':
        if not args:
            print_error("Penggunaan: awk '{print $1}' <file>")
            return True

        prog_args = [a for a in args if not a.startswith('-F') and not a.startswith('-v')]
        fsep     = ' '
        for a in args:
            if a.startswith('-F'):
                fsep = a[2:].strip('"\'') if len(a) > 2 else (args[args.index(a)+1] if args.index(a)+1 < len(args) else ' ')

        program  = prog_args[0].strip("'\"") if prog_args else ''
        fnames   = prog_args[1:] if len(prog_args) > 1 else []

        if not fnames:
            print_error("Harap tentukan file untuk awk.")
            return True

        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                lines = current_dir[fname].split('\n')
                for nr, line in enumerate(lines, 1):
                    fields = line.split(fsep)
                    # Evaluasi program awk sederhana
                    output = line
                    if 'print $0' in program:
                        output = line
                    elif 'print NR' in program:
                        output = str(nr)
                    else:
                        import re
                        m = re.search(r'print \$(\d+)', program)
                        if m:
                            idx = int(m.group(1)) - 1
                            output = fields[idx] if 0 <= idx < len(fields) else ''
                        elif 'print' in program:
                            output = line

                    cond_match = True
                    if f'NR=={nr}' in program or f'NR =={nr}' in program:
                        cond_match = True
                    elif 'NR==' in program:
                        cond_match = False

                    if cond_match:
                        print(f"  {W}{output}{N}")
                command_count['correct'] += 1
            else:
                print_error(f"awk: '{fname}': Tidak ada file atau direktori.")

    # ── cut ───────────────────────────────────────────────────────────────────────
    elif cmd == 'cut':
        delim  = '\t'
        fields = None
        chars  = None
        fnames = []
        i = 0
        while i < len(args):
            if args[i].startswith('-d'):
                delim = args[i][2:].strip('"\'') if len(args[i]) > 2 else args[i+1].strip('"\'')
                if not args[i][2:]: i += 1
            elif args[i] == '-f' and i+1 < len(args):
                fields = int(args[i+1]) - 1; i += 1
            elif args[i].startswith('-f'):
                fields = int(args[i][2:]) - 1
            elif args[i] == '-c' and i+1 < len(args):
                chars = args[i+1]; i += 1
            elif not args[i].startswith('-'):
                fnames.append(args[i])
            i += 1

        for fname in fnames:
            if current_dir and fname in current_dir and isinstance(current_dir[fname], str):
                for line in current_dir[fname].split('\n'):
                    if fields is not None:
                        parts_c = line.split(delim)
                        print(f"  {W}{parts_c[fields] if fields < len(parts_c) else ''}{N}")
                    elif chars is not None:
                        rng = chars.split('-')
                        s = int(rng[0])-1
                        e = int(rng[1]) if len(rng)>1 else s+1
                        print(f"  {W}{line[s:e]}{N}")
                    else:
                        print(f"  {W}{line}{N}")
                command_count['correct'] += 1
            else:
                print_error(f"cut: '{fname}': Tidak ada file atau direktori.")

    # ── tr ────────────────────────────────────────────────────────────────────────
    elif cmd == 'tr':
        print_info("tr memerlukan input dari pipe/stdin. Contoh: echo 'halo' | tr 'a-z' 'A-Z'")
        print_tip("Simulator tidak mendukung pipe, tapi di Linux nyata: echo 'halo' | tr 'a-z' 'A-Z' → 'HALO'")

    # ── man / help ────────────────────────────────────────────────────────────────
    elif cmd in ('man', 'help'):
        if args:
            show_man(args[0])
        else:
            show_help_main()
        command_count['correct'] += 1

    # ── contoh ───────────────────────────────────────────────────────────────────
    elif cmd == 'contoh':
        if args:
            show_examples(args[0])
        else:
            print_error("Penggunaan: contoh <nama_perintah>")
            print_tip("Contoh: contoh ls  atau  contoh chmod  atau  contoh grep")

    # ── cheatsheet ────────────────────────────────────────────────────────────────
    elif cmd == 'cheatsheet':
        show_cheatsheet()
        command_count['correct'] += 1

    # ── quiz ─────────────────────────────────────────────────────────────────────
    elif cmd == 'quiz':
        run_quiz()
        command_count['correct'] += 1

    # ── score ─────────────────────────────────────────────────────────────────────
    elif cmd == 'score':
        total   = command_count['total']
        correct = command_count['correct']
        pct     = (correct / total * 100) if total else 0
        print(f"\n  {C}Statistik Sesi Ini:{N}")
        print(f"  {W}Perintah diketik  : {G}{total}{N}")
        print(f"  {W}Perintah berhasil : {G}{correct}{N}")
        print(f"  {W}Tingkat keberhasilan: {Y}{pct:.1f}%{N}")
        print(f"  {W}Perintah digunakan: {C}{len(set(command_history))}{N} jenis unik\n")

    # ── clear ─────────────────────────────────────────────────────────────────────
    elif cmd == 'clear':
        clear_screen()

    # ── exit ─────────────────────────────────────────────────────────────────────
    elif cmd == 'exit':
        total   = command_count['total']
        correct = command_count['correct']
        print(f"\n{Y}╔{'═'*51}╗")
        print(f"║{C}{BOLD}  Terima kasih telah menggunakan Linux Simulator!  {Y}║")
        print(f"╠{'═'*51}╣")
        print(f"║{W}  Total perintah   : {G}{total:<30}{Y}║")
        print(f"║{W}  Perintah berhasil: {G}{correct:<30}{Y}║")
        print(f"╚{'═'*51}╝{N}")
        print(f"\n{C}   Semangat terus belajar perintah dasar Linux! Kamu pasti bisa!{N}\n")
        return False

    # ── Perintah tidak dikenal ────────────────────────────────────────────────────
    else:
        # Cek apakah ada command serupa
        close = [c for c in COMMAND_INFO if c.startswith(cmd[0]) and abs(len(c)-len(cmd))<=2]
        print_error(f"'{cmd}': Perintah tidak ditemukan.")
        if close:
            print_info(f"Mungkin maksudmu: {', '.join(close[:3])}?")
        print_info("Ketik 'help' untuk melihat semua perintah yang tersedia.")

    return True


def expand_vars(text):
    # ini def untuk expand variabel seperti $HOME, $USER, dll.
    for k, v in env_vars.items():
        text = text.replace(f'${k}', v)
    return text


# ─── MAIN ──────────────────────────────────────────────────────────────────────
def main():
    clear_screen()
    print(BANNER)
    time.sleep(0.5)

    print(f"{W}  Selamat datang di Basic Simulator Linux / Termux{N}\n")
    print(f"{Y}  Catatan:{N}")
    print(f"{W}  - Tool Basic Simulator ini GRATIS untuk pembelajaran{N}")
    print(f"{W}  - Tidak untuk diperjual belikan, cukup follow, stars{N}")
    print(f"{G}    https://github.com/djunekz/termux-app-store{N}\n")
    print(f"{W}  Simulator ini mengajarkan {G}{len(COMMAND_INFO)}{W} perintah Linux / Termux.{N}\n\n")
    print(f"  Ketik {G}help{W}           - daftar semua perintah{N}")
    print(f"  Ketik {G}man <cmd>{W}      - dokumentasi lengkap {Y}(contoh: man ls){N}")
    print(f"  Ketik {G}contoh <cmd>{W}   - contoh penggunaan {Y}(contoh: contoh grep){N}")
    print(f"  Ketik {G}cheatsheet{W}     - ringkasan cepat semua perintah{N}")
    print(f"  Ketik {G}quiz{W}           - uji pengetahuanmu dengan kuis{N}")
    print(f"  Ketik {G}score{W}          - lihat statistik sesimu{N}")
    print(f"  Ketik {G}exit{W}           - keluar{N}\n")
    print(f"{DG}  ─────────────────────────────────────────────────────{N}\n")

    while True:
        try:
            current_dir_display = '/'.join(current_path_list) if current_path_list else '/'
            prompt = (
                f"{Y}┌──[{G}user@basic-linux{Y}]─[{W}~/{current_dir_display}{Y}]\n"
                f"└─{G}$ {N}"
            )
            raw = input(prompt).strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{Y}  (Gunakan 'exit' untuk keluar dengan baik){N}")
            continue

        if not raw:
            continue

        if not execute_command(raw):
            break


if __name__ == '__main__':
    main()
# Selamat membaca dan belajar coding
# Apabila bermanfaat, tolong untuk klik stars (Gambar Bintang)
# di repository: https://github.com/djunekz/termux-app-store
