import os
import tarfile


def _inside(base: str, target: str) -> bool:
    return target == base or target.startswith(base + os.sep)


def validate_tar_members(members, dest: str):
    base = os.path.realpath(dest)
    for m in members:
        if os.path.isabs(m.name):
            raise ValueError(f"Unsafe archive member (absolute path): {m.name}")
        target = os.path.normpath(os.path.join(base, m.name))
        if not _inside(base, target):
            raise ValueError(f"Unsafe archive member (path traversal attempt): {m.name}")
        if m.isdev() or m.isfifo():
            raise ValueError(f"Unsafe archive member (special file): {m.name}")
        if m.issym():
            if os.path.isabs(m.linkname):
                raise ValueError(f"Unsafe symlink target: {m.name} -> {m.linkname}")
            link = os.path.normpath(os.path.join(os.path.dirname(target), m.linkname))
            if not _inside(base, link):
                raise ValueError(f"Unsafe symlink target: {m.name} -> {m.linkname}")
        elif m.islnk():
            if os.path.isabs(m.linkname):
                raise ValueError(f"Unsafe hardlink target: {m.name} -> {m.linkname}")
            link = os.path.normpath(os.path.join(base, m.linkname))
            if not _inside(base, link):
                raise ValueError(f"Unsafe hardlink target: {m.name} -> {m.linkname}")


def extract_tar_member(tar: tarfile.TarFile, member, dest: str, set_attrs: bool = True):
    if hasattr(tarfile, "data_filter"):
        try:
            tar.extract(member, dest, set_attrs=set_attrs, filter="data")
        except tarfile.FilterError as e:
            raise ValueError(str(e))
    else:
        tar.extract(member, dest, set_attrs=set_attrs)


def safe_extract_tar(tar: tarfile.TarFile, dest: str):
    members = tar.getmembers()
    validate_tar_members(members, dest)
    for member in members:
        extract_tar_member(tar, member, dest)
