"""OrChat - A powerful CLI for AI models via OpenRouter."""

__version__ = "1.4.6"

from .main import main

__all__ = ["main"]
