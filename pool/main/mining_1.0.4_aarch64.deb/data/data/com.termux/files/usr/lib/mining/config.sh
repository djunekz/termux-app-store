# Konfigurasi proyek MINING
APP_NAME="MINING"
APP_AUTHOR="Djunekz"
REPO_URL="https://github.com/djunekz/mining"
APP_VERSION="$(cat "$ROOT/VERSION" 2>/dev/null || echo 0.0.0)"

# Data pengguna (akun, wallet) disimpan DI LUAR folder repo
# supaya "git pull" tidak menimpa data.
DATA_DIR="${MINING_HOME:-$HOME/.mining}"

# Batas suhu baterai (derajat C) default; mining dihentikan jika terlewati
MAX_TEMP_DEFAULT=42

# Donasi bawaan xmrig ke pengembang xmrig (persen waktu mining).
# Ditulis eksplisit di sini supaya transparan; aplikasi ini sendiri TIDAK
# memiliki dev-fee atau wallet tersembunyi. Pada xmrig resmi batas minimumnya
# 1% (kMinimumDonateLevel di src/donate.h), jadi nilai di bawah 1 tidak
# dijamin menonaktifkannya. xmrig dikompilasi dari sumber resmi tanpa patch.
XMRIG_DONATE=1

# Tipe miner yang dikenali oleh file koin
MINER_TYPES="xmrig ccminer cpuminer none"
